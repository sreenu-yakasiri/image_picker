import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import '../utils/app_url.dart';

class HTTP {
  static Future<String> sendPostRequest({required String URL}) async {
      var url = Uri.https(
        AppUrl.baseURL,
        URL,
      );
      var response = await http.post(url);
      if (response.statusCode == 200) {
        return response.body;
      } else {
        debugPrint(response.reasonPhrase);
        throw Exception(response.reasonPhrase);
      }
  }
}
