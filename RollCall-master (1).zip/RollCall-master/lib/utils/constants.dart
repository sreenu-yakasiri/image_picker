import 'package:flutter/material.dart';
import 'package:pinput/pinput.dart';

const ToolBarTextHeaderStyle = TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold);
const ToolBarTextHeaderStyleNormal = TextStyle(fontSize: 20.0, fontWeight: FontWeight.normal);
const kHead1TextStyle = TextStyle(fontSize: 50.0, fontWeight: FontWeight.bold);
const kHead2TextStyle = TextStyle(fontSize: 30.0, fontWeight: FontWeight.bold);
const kHead3TextStyle = TextStyle(fontSize: 18.0,);
const MenuTitleTextStyle = TextStyle(fontSize: 18.0,fontWeight: FontWeight.bold);
const SubMenuTitleTextStyle = TextStyle(fontSize: 14.0,fontWeight: FontWeight.bold);
const kTitleTextStyle = TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold);
const kBodyTextStyle = TextStyle(
  fontSize: 12.0,
);

// OTP Page
const focusedBorderColor = Color.fromRGBO(23, 171, 144, 1);
const fillColor = Color.fromRGBO(243, 246, 249, 0);
const borderColor = Color.fromRGBO(23, 171, 144, 0.4);

const double elevation = 4;
const double cardRadius = 4;

final defaultPinTheme = PinTheme(
  width: 56,
  height: 56,
  textStyle: const TextStyle(
    fontSize: 22,
    color: Color.fromRGBO(30, 60, 87, 1),
  ),
  decoration: BoxDecoration(
    borderRadius: BorderRadius.circular(19),
    border: Border.all(color: borderColor),
  ),
);
