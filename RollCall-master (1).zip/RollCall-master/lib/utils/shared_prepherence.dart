import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';


class Preferences {
  static Future<bool> saveStringToSP(String key, String value) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.setString(key, value);
  }

  static Future<bool> removeStringFromSP(String key) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.remove(key);
  }

  static Future<String?> getStringFromSp(String key) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString(key);
  }
  //
  // Future<bool> saveUser(UserProfile usaveStringToSPser) async {
  //   final SharedPreferences prefs = await SharedPreferences.getInstance()
  //
  //   await prefs.setInt("userId", user.id!);
  //   await  prefs.setString("name", user.name!);
  //   await prefs.setString("email", user.email!);
  //   await prefs.setString("phone", user.mobile!);
  //   await prefs.setString("role_id", '${user.roleId}');
  //   await prefs.setInt("status", user.status!);
  //   await prefs.setString("tenant_id", user.tenantId!);
  //   await prefs.setString("profile_photo_url", user.profilePhotoUrl!);
  //   await prefs.setString("authToken", user.authToken!);
  //
  //   return true;
  // }
  //
  // Future<UserProfile> getUser() async {
  //   final SharedPreferences prefs = await SharedPreferences.getInstance();
  //
  //   int? userId = prefs.getInt("userId");
  //   String name = prefs.getString("name");
  //   String email = prefs.getString("email");
  //   String phone = prefs.getString("phone");
  //   String type = prefs.getString("type");
  //   String token = prefs.getString("token");
  //   String renewalToken = prefs.getString("renewalToken");
  //
  //   return UserProfile(
  //       userId: userId,
  //       name: name,
  //       email: email,
  //       phone: phone,
  //       type: type,
  //       token: token,
  //       renewalToken: renewalToken);
  // }
  //
  // void removeUser() async {
  //   final SharedPreferences prefs = await SharedPreferences.getInstance();
  //
  //   prefs.remove("name");
  //   prefs.remove("email");
  //   prefs.remove("phone");
  //   prefs.remove("type");
  //   prefs.remove("token");
  // }
  //
  // Future<String> getToken(args) async {
  //   final SharedPreferences prefs = await SharedPreferences.getInstance();
  //   String token = prefs.getString("token");
  //   return token;
  // }
}
