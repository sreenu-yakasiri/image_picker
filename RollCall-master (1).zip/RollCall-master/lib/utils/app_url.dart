class AppUrl {
  static const String liveBaseURL = "rollcall.varthmaan.com";
  static const String localBaseURL = "";
  static const String baseURL = liveBaseURL;
  static const String protocol = "https://";

  static const String loginURL = "/api/login/user";
  static const String verifyOTPURL = "/api/login/otp/verify";
  static const String bannersURL = "/api/banner/list";
  static const String applyLeaveURL = "/api/apply/leave";
  static const String leaveTypesURL = "/api/leave/type";
  static const String appliedLeavesURL = "/api/leave/list";
  static const String activeTaskList = "/api/list/tasklist";
  static const String completeTaskList = "/api/list/complete/tasklist";
  static const String availableLeavesURL = "/api/available/leave/list";
  static const String holidaysListURL = "/api/holiday/list";
  static const String checkInOutURL = "/api/attendance/log";
  static const String checkInOutHistoryURL = "/api/attendance/log/history";
  static const String updateFcmToken = "/api/update/fcm";
  static const String uploadDoc = "/api/task/document/update";
  static const String deleteDoc = "/api/task/document/delete";

  //regular constants
  static const String appName = "RollCall";
  static const String leaveType = "leave";
  static const String genericErrorMessage =
      "Something went wrong, please try again.";
  static const int TASK_COMPLETE_ID = 3;
}
