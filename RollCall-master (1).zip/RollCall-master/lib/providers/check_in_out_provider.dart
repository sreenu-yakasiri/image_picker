import 'dart:async';
import 'dart:convert';

import 'package:device_info/device_info.dart';
import 'package:employee_attendance/models/check_in_out_model.dart';
import 'package:employee_attendance/utils/app_url.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';

import 'check_in_out_log_provider.dart';

class CheckInOutProvider with ChangeNotifier {
  static late CheckInOutModel checkInOutModel;
  bool isLoading = false;
  bool isCheckedIn = false;

  setIsLoading(bool isLoading) {
    this.isLoading = isLoading;
    notifyListeners();
  }

  setIsCheckedIn(bool isCheckedIn) {
    this.isCheckedIn = isCheckedIn;
    notifyListeners();
  }

  getDeviceInfo(BuildContext context) async {
    const platformMethodChannel = MethodChannel('nativeChannel');
    var info = platformMethodChannel.invokeMethod('deviceInfo');
    return info;
  }

  getBatteryLevel(BuildContext context) async {
    const platformMethodChannel = MethodChannel('nativeChannel');
    var level = await platformMethodChannel.invokeMethod('batteryInfo');
    return level;
  }

  Future<CheckInOutModel> checkInOut(
      {required String userID,
      required String type,
      required String lat,
      required String long,
      required BuildContext context}) async {
    try {
      setIsLoading(true);

      final DeviceInfoPlugin deviceInfoPlugin = new DeviceInfoPlugin();
      var build = await deviceInfoPlugin.androidInfo;
      var deviceId = build.androidId;

      var url = Uri.https(AppUrl.baseURL, AppUrl.checkInOutURL, {
        'user_id': userID,
        'type': type,
        'latitude': lat,
        'longitude': long,
        'battery_status': await getBatteryLevel(context),
        'device_info': await getDeviceInfo(context),
        'device_id': deviceId,
      });
      var response = await http.post(url);
      if (response.statusCode == 200) {
        if (response.body.isNotEmpty) {
          checkInOutModel = checkInOutModelFromJson(response.body);
          context.read<CheckInOutLogProvider>().checkInOutLog(context, userID);
          notifyListeners();
        } else {
          setIsLoading(false);
          return Future.error(response.reasonPhrase.toString());
        }
      } else {
        setIsLoading(false);
        return Future.error(json.decode(response.body)["message"]);
      }
    } catch (e) {
      debugPrint(e.toString());
      setIsLoading(false);

      return Future.error(e.toString());
    }
    setIsLoading(false);
    return checkInOutModel;
  }
}
