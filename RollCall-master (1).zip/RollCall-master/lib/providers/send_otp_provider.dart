import 'dart:async';

import 'package:employee_attendance/utils/app_url.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../models/otp_model.dart';

class SendOTPProvider with ChangeNotifier {
  bool isLoading = false;
  late OtpModel otpModel;
  String? error;
  late String mobileNumber;

  // Send OTP to mobile number
  Future<OtpModel> sendOTP(String mobile) async {
    debugPrint('Send');
    mobileNumber = '91$mobile';
    try {
      isLoading = true;
      notifyListeners();
      var url =
          Uri.https(AppUrl.baseURL, AppUrl.loginURL, {'mobile': mobileNumber});
      var response = await http.post(url);
      if (response.statusCode == 200) {
        otpModel = otpModelFromJson(response.body);
        notifyListeners();
        debugPrint(otpModel.otp.toString());
        debugPrint(otpModel.message);
      } else {
        error = response.reasonPhrase;
        notifyListeners();
        debugPrint(response.reasonPhrase);
      }
    } catch (e) {
      isLoading = false;
      error = e.toString();
      notifyListeners();
      debugPrint(e.toString());
    }
    isLoading = false;
    notifyListeners();
    return otpModel;
  }
}
