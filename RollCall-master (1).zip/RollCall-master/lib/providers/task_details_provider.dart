import 'dart:io';

import 'package:employee_attendance/models/api_response_model.dart';
import 'package:employee_attendance/ui/components/common-widgets.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';

import '../utils/app_url.dart';
import '../utils/permission_helper.dart';
import 'DataProvider.dart';

class TaskDetailsProvider with ChangeNotifier {
  late List<String?> uploadedImage = [];
  String message = "";
  String buttonName = "Submit";
  bool isLoading = false;

  void setIsLoading(bool isLoading) {
    this.isLoading = isLoading;
    buttonName = this.isLoading ? "Uploading data..." : "Submit";
    notifyListeners();
  }

  void setMessage(String message) {
    this.message = message;
    notifyListeners();
  }

  void addImageToList(String? imagePath) {
    uploadedImage.add(imagePath);
    notifyListeners();
  }

  void addImagesToList(var images) {
    uploadedImage.addAll(images);
    notifyListeners();
  }

  void removeImageToList(int index) {
    uploadedImage.removeAt(index);
    notifyListeners();
  }

  Future<ApiResponseModel?> deleteImage(
      BuildContext context, String docId, int imageIndex) async {
    var model = new ApiResponseModel(
        success: false, message: AppUrl.genericErrorMessage);
    debugPrint("RC: request doc id: " + docId);

    try {
      var url = Uri.https(AppUrl.baseURL, AppUrl.deleteDoc, {'id': docId});
      var response = await http.post(url);
      debugPrint("RC: response doc delete: " + response.toString());

      if (response.statusCode == 200) {
        if (response.body.isNotEmpty) {
          model = apiResponseFromJson(response.body);
          new CommonWidgets().showSnackbar(model.message, context);
          removeImageToList(imageIndex);
          context.read<DataProvider>().setIsRefreshTaskListPage(true);
        } else {}
      }
    } catch (e) {
      debugPrint(e.toString());
    }
    return model;
  }

  uploadImagesApi(BuildContext context, List<String> uploadImages,
      String message, String taskId, String userId) async {
    setIsLoading(true);
    Position position = await PermissionsHelper().determinePosition();

    var request = http.MultipartRequest(
      'POST',
      Uri.parse(AppUrl.protocol + AppUrl.baseURL + AppUrl.uploadDoc),
    );
    Map<String, String> headers = {"Content-type": "multipart/form-data"};
    for (int i = 0; i < uploadImages.length; i++) {
      var imageFile = File(uploadImages[i]);

      request.files.add(
        http.MultipartFile(
          'file[]',
          imageFile.readAsBytes().asStream(),
          imageFile.lengthSync(),
          filename: imageFile.path.split('/').last,
        ),
      );
    }
    request.fields['message'] = message;
    request.fields['task_id'] = taskId;
    request.fields['user_id'] = userId;
    request.fields['lat'] = position.latitude.toString();
    request.fields['lang'] = position.longitude.toString();

    request.headers.addAll(headers);
    debugPrint("RC: request: " + request.fields.toString());
    debugPrint("RC: request files: " + request.files.toString());
    var res = await request.send();
    http.Response response = await http.Response.fromStream(res);
    debugPrint('RC: body' + response.body);
    debugPrint('RC: ' + response.statusCode.toString());
    setIsLoading(false);
    new CommonWidgets().showSnackbar("Data updated successfully.", context);
  }
}
