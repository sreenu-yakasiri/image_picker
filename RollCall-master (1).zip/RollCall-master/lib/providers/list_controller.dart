import 'package:employee_attendance/models/task_list_model.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../utils/app_url.dart';

class ListController with ChangeNotifier {
  late TaskListModel? activeTasks = null;
  bool isLoading = false;

  getTasks(String tabUrl, String userID, String token) async {
    try {
      isLoading = true;
      notifyListeners();
      var url = Uri.https(AppUrl.baseURL, tabUrl,
          {'user_id': userID, 'token': token, 'offset': '1', 'limit': '10000'});
      var response = await http.post(url);
      if (response.statusCode == 200) {
        if (response.body.isNotEmpty) {
          activeTasks = taskListFromJson(response.body);
        }
      }
    } catch (e) {
      debugPrint(e.toString());
    }

    isLoading = false;
    notifyListeners();
  }

  getCompletedTasks(String tabUrl, String userID, String token) async {
    try {
      isLoading = true;
      notifyListeners();
      var url = Uri.https(AppUrl.baseURL, tabUrl, {
        'user_id': userID,
        'token': token,
        'timespan': 'custom',
        'to_date': '2050-01-01',
        'from_date': '1990-01-01',
        'page': '1',
        'limit': '25',
      });
      var response = await http.post(url);
      if (response.statusCode == 200) {
        if (response.body.isNotEmpty) {
          activeTasks = taskListFromJson(response.body);
        } else {
          //throw Exception(response.reasonPhrase);
          debugPrint(response.reasonPhrase);
        }
      } else {
        activeTasks = null;
      }
    } catch (e) {
      activeTasks = null;
      debugPrint(e.toString());
    }

    isLoading = false;
    notifyListeners();
  }
}
