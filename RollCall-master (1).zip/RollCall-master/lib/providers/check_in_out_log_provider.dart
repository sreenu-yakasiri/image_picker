import 'dart:async';

import 'package:employee_attendance/models/check_in_out_log-history_model.dart';
import 'package:employee_attendance/providers/check_in_out_provider.dart';
import 'package:employee_attendance/utils/app_url.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';

class CheckInOutLogProvider with ChangeNotifier {
  CheckInOutLogHistoryModel? model;
  CheckInOutLogHistoryModel? get logList => model;

  Future<void> checkInOutLog(BuildContext context, String userID) async {
    try {
      var url = Uri.https(
          AppUrl.baseURL, AppUrl.checkInOutHistoryURL, {'user_id': userID});
      var response = await http.post(url);
      if (response.statusCode == 200) {
        if (response.body.isNotEmpty) {
          model = checkInOutLogHistoryModelFromJson(response.body);
          if (model!.attendanceList!.length > 0 &&
              model!.attendanceList![0].subType == "1") {
            //checking if last attendence is check in.
            context.read<CheckInOutProvider>().setIsCheckedIn(true);
          } else {
            context.read<CheckInOutProvider>().setIsCheckedIn(false);
          }

          notifyListeners();
        } else {
          throw Exception(response.reasonPhrase);
        }
      }
    } catch (e) {
      debugPrint(e.toString());
      throw Exception(e.toString());
    }
    //return model;
  }
}
