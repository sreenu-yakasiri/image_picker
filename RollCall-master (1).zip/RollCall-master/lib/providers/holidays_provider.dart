import 'dart:async';

import 'package:employee_attendance/utils/app_url.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../models/holidays_list_model.dart';

class HolidaysProvider {
  static late HolidaysListModel holidaysListModel;

  static Future<HolidaysListModel> getHolidays(String tenatID) async {
    debugPrint('Fetching holidays..');
    try {
      var url = Uri.https(AppUrl.baseURL, AppUrl.holidaysListURL,
          {'tenant_id': tenatID, 'page': '0', 'fetch_all': '1'});
      var response = await http.post(url);
      if (response.statusCode == 200) {
        if (response.body.isNotEmpty) {
          holidaysListModel = holidaysListModelFromJson(response.body);
        } else {
          throw Exception(response.reasonPhrase);
          debugPrint(response.reasonPhrase);
        }
      }
    } catch (e) {
      debugPrint(e.toString());
      throw Exception(e.toString());
    }
    return holidaysListModel;
  }
}

// class AppliedLeavesProvider with ChangeNotifier {
//   bool isLoading = false;
//   AppliedLeavesModel? appliedLeavesModel;
//   String? error;
//
//   // AppliedLeavesProvider() {
//   //   getAppliedLeaves();
//   // }
//
//   Future<AppliedLeavesModel?> getAppliedLeaves() async {
//     try {
//       debugPrint('Fetching Leaves..');
//       isLoading = true;
//       notifyListeners();
//
//       var url = Uri.https(AppUrl.baseURL, AppUrl.appliedLeavesURL,
//           {'user_id': '1384', 'page': '1', 'fetch_all': '0'});
//       var response = await http.post(url);//http://varthmaan.com/api/apply/leave?user_id=1384&page=1&fetch_all=0
//       if (response.statusCode == 200) {
//         if (response.body.isNotEmpty) {
//           appliedLeavesModel = appliedLeaveFromJson(response.body);
//         } else {
//           error = response.reasonPhrase;
//           debugPrint(response.reasonPhrase);
//         }
//       }
//     } catch (e) {
//       error = e.toString();
//       debugPrint(e.toString());
//     }
//     isLoading = false;
//     notifyListeners();
//     return appliedLeavesModel;
//   }
// }
