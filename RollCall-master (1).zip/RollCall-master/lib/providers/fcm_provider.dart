import 'dart:io';

import 'package:device_info/device_info.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../utils/app_url.dart';

class FcmProvider{
  Future<void> updateFcmToken(String fcmToken, userID) async {
    debugPrint('Send');
    final DeviceInfoPlugin deviceInfoPlugin = new DeviceInfoPlugin();
    var deviceId = null;
    if(fcmToken != null)
    {
      try {
        if(Platform.isAndroid)
          {
            var build = await deviceInfoPlugin.androidInfo;
            deviceId = build.androidId;
          }
        else
          {
            var data = await deviceInfoPlugin.iosInfo;
            deviceId = data.identifierForVendor;
          }

        var url = Uri.https(AppUrl.baseURL, AppUrl.updateFcmToken, {
          'user_id': userID,
          'fcm_id': fcmToken,
          'device_id': deviceId,
        });
        var response = await http.post(url);
        if (response.statusCode == 200) {
          debugPrint(response.body);
        } else {
          debugPrint(response.reasonPhrase);
        }
      } catch (e) {
        debugPrint(e.toString());
      }
    }
  }
}