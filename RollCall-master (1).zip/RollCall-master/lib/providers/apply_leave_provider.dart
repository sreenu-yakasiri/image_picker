import 'dart:async';
import 'dart:convert';

import 'package:employee_attendance/utils/app_url.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class ApplyLeaveProvider with ChangeNotifier {
  bool isLoading = false;
  dynamic data;
  String? error;

  // Send OTP to mobile number
  Future<dynamic> applyLeave(String fromDate, toDate, leaveType, userID) async {
    debugPrint('Send');

    if (leaveType != null) {
      try {
        isLoading = true;
        notifyListeners();
        //var userID = await Preferences.getStringFromSp('user_id');
        var url = Uri.https(AppUrl.baseURL, AppUrl.applyLeaveURL, {
          'user_id': userID,
          'to_date': toDate,
          'from_date': fromDate,
          'leave_type': leaveType,
        });
        var response = await http.post(url);
        if (response.statusCode == 200) {
          await Future.delayed(Duration(seconds: 2));
          data = json.decode(response.body);
          debugPrint(data['success'].toString());
        } else {
          error = response.reasonPhrase;
          debugPrint(response.reasonPhrase);
        }
      } catch (e) {
        isLoading = false;
        error = e.toString();
        debugPrint(e.toString());
      }
      isLoading = false;
      notifyListeners();
    } else {
      data = "Please select Leave Type.";
    }

    return data;
  }
}
