import 'package:flutter/foundation.dart';

import '../models/task_list_model.dart';

class DataProvider extends ChangeNotifier {
  Data? taskData;
  bool isRefreshTaskList = false;

  setIsRefreshTaskListPage(bool status) {
    this.isRefreshTaskList = status;
    //notifyListeners();
  }

  setTaskData(Data? taskData) {
    this.taskData = taskData;
    notifyListeners();
  }
}
