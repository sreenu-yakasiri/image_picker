import 'package:flutter/foundation.dart';
import '../models/user_profile.dart';
import '../utils/shared_prepherence.dart';

class UserProvider extends ChangeNotifier {
  late UserProfile currentUser;
  String notificationRoutePage = "";

  void setUser(UserProfile user) {
    currentUser = user;
    // This call tells the widgets that are listening to this model to rebuild.
    notifyListeners();
  }

  void setNotificationRoutePage(String routePage)
  {
    notificationRoutePage = routePage;
  }

  Future<void> removeUser() async {
    currentUser = UserProfile();
    await Preferences.removeStringFromSP('tenant_id');
    await Preferences.removeStringFromSP('user_profile_json');
    // This call tells the widgets that are listening to this model to rebuild.
    notifyListeners();
  }
}
