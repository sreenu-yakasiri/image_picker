import 'dart:async';

import 'package:employee_attendance/models/banners_model.dart';
import 'package:employee_attendance/providers/user_provider.dart';
import 'package:employee_attendance/utils/app_url.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';

import '../utils/shared_prepherence.dart';

class BannersProvider extends ChangeNotifier {
  bool isLoading = false;
  BannersModel? bannersModel;
  String? error;

  BannersProvider() {}

  initiateLocationService(BuildContext context) async {
    String userID = context.read<UserProvider>().currentUser.id.toString();

    const platformMethodChannel = MethodChannel('nativeChannel');
    var result =
        await platformMethodChannel.invokeMethod('checkPermissions', userID);
    if (result) {
      await platformMethodChannel.invokeMethod('startLocationService', {
        "userID": userID,
        "locationTimeInterval": bannersModel!.locationTime.toString()
      });
    }
  }

  Future<BannersModel?> getBanners(BuildContext context) async {
    try {
      debugPrint('Banners fetching from server..');
      isLoading = true;
      notifyListeners();

      var tenantID = await Preferences.getStringFromSp('tenant_id');
      var url =
          Uri.https(AppUrl.baseURL, AppUrl.bannersURL, {'tenant_id': tenantID});
      var response = await http.post(url);
      if (response.statusCode == 200) {
        if (response.body.isNotEmpty) {
          bannersModel = bannersModelFromJson(response.body);
          debugPrint(response.reasonPhrase);
          initiateLocationService(context);
        } else {
          error = response.reasonPhrase;
          debugPrint(response.reasonPhrase);
        }
      }
    } catch (e) {
      error = e.toString();
      debugPrint(e.toString());
    }
    isLoading = false;
    notifyListeners();
    return bannersModel;
  }
}
