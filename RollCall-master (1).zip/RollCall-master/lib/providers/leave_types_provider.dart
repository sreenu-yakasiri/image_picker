import 'dart:async';

import 'package:employee_attendance/models/leave_types_model.dart';
import 'package:employee_attendance/utils/app_url.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../utils/shared_prepherence.dart';

class LeaveTypesProvider {
  static late LeaveTypesModel leaveTypesModel;
  // Send OTP to mobile number

  static Future<LeaveTypesModel> getLeaveTypes() async {
    var tenantID = await Preferences.getStringFromSp('tenant_id');

    debugPrint('Fetching Leave types..');
    try {
      var url = Uri.https(
          AppUrl.baseURL, AppUrl.leaveTypesURL, {'tenant_id': tenantID});
      var response = await http.post(url);
      if (response.statusCode == 200) {
        leaveTypesModel = leaveTypesModelFromJson(response.body);
      } else {
        debugPrint(response.reasonPhrase);
        throw Exception(response.reasonPhrase);
      }
    } catch (e) {
      debugPrint(e.toString());
      throw Exception(e.toString());
    }
    return leaveTypesModel;
  }
}
