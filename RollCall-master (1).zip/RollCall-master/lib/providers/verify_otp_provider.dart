import 'dart:async';
import 'package:employee_attendance/models/user_profile.dart';
import 'package:employee_attendance/utils/app_url.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import '../models/otp_model.dart';
import '../models/verify_otp_model.dart';
import '../utils/shared_prepherence.dart';

class VerifyOTPProvider with ChangeNotifier {
  bool isLoading = false;
  VerifyOtpModel? verifyOtpModel;
  String? error;

  // Send OTP to mobile number
  Future<VerifyOtpModel?> verifyOTP(String mobile, String otp) async {
    try {
      isLoading = true;
      notifyListeners();

      var url = Uri.https(
          AppUrl.baseURL, AppUrl.verifyOTPURL, {'mobile': mobile, 'otp': otp});
      var response = await http.post(url);

      if (response.statusCode == 200) {
        verifyOtpModel = verifyOtpModelFromJson(response.body);
        if(verifyOtpModel!.success){
         //await Preferences.saveStringToSP('user_id', '${verifyOtpModel!.profile!.id!}');
         //await Preferences.saveStringToSP('user_name', verifyOtpModel!.profile!.name!);
         await Preferences.saveStringToSP('tenant_id', verifyOtpModel!.profile!.tenantId!);
         //await Preferences.saveStringToSP('profile_photo_url', verifyOtpModel!.profile!.profilePhotoUrl!);
         await Preferences.saveStringToSP('user_profile_json', userProfileToJson(verifyOtpModel!.profile!));
         //debugPrint(isSaved.toString());
        }else{
          //await Preferences.removeStringFromSP('user_id');
          //await Preferences.removeStringFromSP('user_name');
          //await Preferences.removeStringFromSP('profile_photo_url');
          await Preferences.removeStringFromSP('tenant_id');
          await Preferences.removeStringFromSP('user_profile_json');
        }
        debugPrint(verifyOtpModel?.message);
      } else {
        error = response.reasonPhrase;
        debugPrint(response.reasonPhrase);
      }
    } catch (e) {
      error = e.toString();
      debugPrint(e.toString());
      notifyListeners();
    }
    isLoading = false;
    notifyListeners();
    return verifyOtpModel;
  }
}
