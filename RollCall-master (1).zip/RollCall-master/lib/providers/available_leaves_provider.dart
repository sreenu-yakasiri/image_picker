import 'dart:async';

import 'package:employee_attendance/models/available_leaves_model.dart';
import 'package:employee_attendance/utils/app_url.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../utils/shared_prepherence.dart';

class AvailableLeavesProvider {
  static late AvailableLeavesModel model;
  static Future<AvailableLeavesModel> getAvailableLeaves(String userID) async {
    debugPrint('Fetching Leave by types..');
    try {
      var tenantID = await Preferences.getStringFromSp('tenant_id');

      var url = Uri.https(AppUrl.baseURL, AppUrl.availableLeavesURL,
          {'user_id': userID, 'tenant_id': tenantID});
      var response = await http.post(url);
      if (response.statusCode == 200) {
        if (response.body.isNotEmpty) {
          model = availableLeavesModelFromJson(response.body);
        } else {
          throw Exception(response.reasonPhrase);
        }
      }
    } catch (e) {
      debugPrint(e.toString());
      throw Exception(e.toString());
    }
    return model;
  }
}
