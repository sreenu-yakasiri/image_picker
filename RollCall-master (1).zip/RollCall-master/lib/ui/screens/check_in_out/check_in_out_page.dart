import 'package:employee_attendance/models/check_in_out_log-history_model.dart';
import 'package:employee_attendance/providers/check_in_out_log_provider.dart';
import 'package:employee_attendance/ui/components/common-widgets.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';

import '../../../main.dart';
import '../../../providers/check_in_out_provider.dart';
import '../../../providers/user_provider.dart';
import '../../../utils/constants.dart';
import '../../../utils/permission_helper.dart';

class CheckInOutPage extends StatefulWidget {
  const CheckInOutPage({super.key});

  @override
  State<CheckInOutPage> createState() => _MyHomePageState();
}

class CheckInOutModel {
  int id;
  String name;

  CheckInOutModel({required this.id, required this.name});
}

class _MyHomePageState extends State<CheckInOutPage> {
  late Future<CheckInOutLogHistoryModel> checkInOutLogModel;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext buildContext) {
    // Initial Selected Value

/*    List<CheckInOutModel> checkInOut = [
      CheckInOutModel(id: 0, name: "Check Out"),
      CheckInOutModel(id: 2, name: "Lunch Break"),
      CheckInOutModel(id: 3, name: "Snacks Break"),
      CheckInOutModel(id: 4, name: "Dinner Break"),
      CheckInOutModel(id: 5, name: "Log Off")
    ];*/

/*
    late CheckInOutModel dropdownValue = checkInOut[0];
*/

    return Scaffold(
      appBar: AppBar(
          elevation: elevation,
          shadowColor: Theme.of(context).shadowColor,
          title: const Text(
            'Check In/Out',
            style: kHead3TextStyle,
          )),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Consumer<CheckInOutProvider>(
          builder: (context, model, child) => model.isLoading
              ? Center(child: Text("Registering attendence, please wait..."))
              : Column(
                  children: [
                    SizedBox(
                        height: 200,
                        width: 200,
                        child: Image.asset('assets/images/timings.png')),
                    Padding(
                      padding: const EdgeInsets.only(top: 16.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(right: 4.0),
                              child: SizedBox(
                                height: 50,
                                child: ElevatedButton(
                                  style: TextButton.styleFrom(
                                      backgroundColor: model.isCheckedIn
                                          ? Colors.black12
                                          : Colors.yellow,
                                      shape: const RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.all(Radius.zero))),
                                  child: const Text(
                                    'Check In',
                                    style: TextStyle(
                                        fontSize: 14, color: Colors.black),
                                  ),
                                  onPressed: () {
                                    if (model.isCheckedIn) {
                                      new CommonWidgets().showSnackbar(
                                          "You are already checked In.",
                                          buildContext);
                                    } else {
                                      _showAlertDialog(context,
                                          "Please confirm to Check In.", 1);
                                    }
                                  },
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            child: SizedBox(
                              height: 50,
                              child: ElevatedButton(
                                  style: TextButton.styleFrom(
                                      backgroundColor: model.isCheckedIn
                                          ? Colors.greenAccent
                                          : Colors.black12,
                                      shape: const RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.all(Radius.zero))),
                                  child: const Text(
                                    'Check Out',
                                    style: TextStyle(
                                        fontSize: 14, color: Colors.black),
                                  ),
                                  onPressed: () {
                                    if (model.isCheckedIn) {
                                      _showAlertDialog(context,
                                          "Please confirm to Check Out.", 5);
                                    } else {
                                      new CommonWidgets().showSnackbar(
                                          "You are already checked out.",
                                          buildContext);
                                    }
                                  }),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                        padding: EdgeInsets.only(top: 16.0),
                        child: Text('Logs',
                            style: TextStyle(
                                fontSize: 18, fontWeight: FontWeight.bold)),
                      ),
                    ),
                    LogHistory()
                    /*ChangeNotifierProvider<CheckInOutLogProvider>(
              create: (_) => CheckInOutLogProvider(),
              child: LogHistory(),
            )*/
                  ],
                ),
        ),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}

class LogHistory extends StatefulWidget {
  const LogHistory({super.key});

  @override
  State<LogHistory> createState() => _LogHistoryState();
}

class _LogHistoryState extends State<LogHistory> {
  //late Future<CheckInOutLogHistoryModel> checkInOutLogModel;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    var userId = context.read<UserProvider>().currentUser!.id.toString();
    context.read<CheckInOutLogProvider>().checkInOutLog(context, userId);
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<CheckInOutLogProvider>(
        builder: (context, model, child) => Flexible(
              child: model.logList?.attendanceList.length == 0
                  ? Text("No data.")
                  : ListView.builder(
                      scrollDirection: Axis.vertical,
                      shrinkWrap: true,
                      padding: const EdgeInsets.only(top: 8),
                      itemCount: model.logList?.attendanceList.length ?? 0,
                      itemBuilder: (BuildContext context, int index) {
                        return Container(
                            color: index % 2 == 0
                                ? Colors.lightBlue[100]
                                : Colors.blue[50],
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                '${model.logList?.attendanceList[index].subtypeName} - ${model.logList?.attendanceList[index].logDateTime.toString()}',
                                style: kHead3TextStyle,
                              ),
                            ));
                      },
                    ),
            ));
  }
}

void _showAlertDialog(BuildContext mainContext, String message, int type) {
  showDialog(
    context: mainContext,
    builder: (BuildContext context) {
      return AlertDialog(
        title: const Text("Alert"),
        content: Text(message),
        actions: [
          TextButton(
            child: const Text("Cancel"),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
          TextButton(
            child: const Text("OK"),
            onPressed: () {
              Navigator.of(context).pop();
              callCheckInOut(mainContext, type.toString());
            },
          ),
        ],
      );
    },
  );
}

/*

void getCheckInOutLogHistory(BuildContext context) {
  String userID = context.read<UserProvider>().currentUser!.id.toString();
  CheckInOutLogProvider.checkInOutLog(userID).then(
    (value) => {
      Navigator.of(context).pop(),
      if (value.success)
        {
          ScaffoldMessenger.of(context)
              .showSnackBar(SnackBar(content: Text(value.message))),
        }
      else
        {
          ScaffoldMessenger.of(context)
              .showSnackBar(SnackBar(content: Text(value.message))),
        }
    },
  );
}
*/

Future<void> callCheckInOut(BuildContext context, String type) async {
  context.read<CheckInOutProvider>().setIsLoading(true);
  String userID = context.read<UserProvider>().currentUser.id.toString();
  Position position = await PermissionsHelper().determinePosition();

  context
      .read<CheckInOutProvider>()
      .checkInOut(
          userID: userID,
          type: type,
          lat: position.latitude.toString(),
          long: position.longitude.toString(),
          context: context)
      .then(
        (value) => {
          if (value.success)
            {
              scaffoldMessengerKey.currentState?.showSnackBar(SnackBar(
                content: Text(value?.message ?? ""),
              ))
            }
          else
            {
              scaffoldMessengerKey.currentState?.showSnackBar(SnackBar(
                content: Text(value.message ?? ""),
              ))
            },
        },
      )
      .catchError((error) {
    scaffoldMessengerKey.currentState?.showSnackBar(SnackBar(
      content: Text(error),
    ));
  });
}
