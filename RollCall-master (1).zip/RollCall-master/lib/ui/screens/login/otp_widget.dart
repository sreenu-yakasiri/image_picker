import 'package:employee_attendance/providers/send_otp_provider.dart';
import 'package:flutter/material.dart';
import 'package:pinput/pinput.dart';
import 'package:provider/provider.dart';
import '../../../providers/user_provider.dart';
import '../../../providers/verify_otp_provider.dart';
import '../../../utils/constants.dart';
import '../../components/custom_button.dart';

class OTPWidget extends StatefulWidget {
  const OTPWidget({Key? key}) : super(key: key);

  @override
  State<OTPWidget> createState() => _OTPWidgetState();
}

class _OTPWidgetState extends State<OTPWidget> {
  final pinController = TextEditingController();
  final focusNode = FocusNode();
  final formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    pinController.dispose();
    focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    SendOTPProvider mobileNumberProvider =
        Provider.of<SendOTPProvider>(context);

    VerifyOTPProvider verifyOTPProvider =
        Provider.of<VerifyOTPProvider>(context);

    /// Optionally you can use form to validate the Pinput
    return SafeArea(
      child: Form(
        key: formKey,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            const SizedBox(
              height: 30.0,
            ),
            const Hero(
              tag: 'appLogo',
              child: FlutterLogo(
                size: 150,
              ),
            ),
            const SizedBox(
              height: 30.0,
            ),
            const Text(
              'Enter your OTP',
              style: kHead2TextStyle,
            ),
            const SizedBox(
              height: 20.0,
            ),
            Directionality(
              // Specify direction if desired
              textDirection: TextDirection.ltr,
              child: Pinput(
                controller: pinController,
                focusNode: focusNode,
                androidSmsAutofillMethod:
                    AndroidSmsAutofillMethod.smsUserConsentApi,
                listenForMultipleSmsOnAndroid: true,
                defaultPinTheme: defaultPinTheme,
                separatorBuilder: (index) => const SizedBox(width: 8),
                // validator: (value) {
                //   return verifyOTPProvider.verifyOtpModel.success
                //       ? null
                //       : 'Pin is incorrect';
                // },
                // onClipboardFound: (value) {
                //   debugPrint('onClipboardFound: $value');
                //   pinController.setText(value);
                // },
                hapticFeedbackType: HapticFeedbackType.lightImpact,
                onCompleted: (pin) {
                  debugPrint('onCompleted: $pin');
                },
                onChanged: (value) {
                  debugPrint('onChanged: $value');
                },
                cursor: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                      margin: const EdgeInsets.only(bottom: 9),
                      width: 22,
                      height: 1,
                      color: focusedBorderColor,
                    ),
                  ],
                ),
                focusedPinTheme: defaultPinTheme.copyWith(
                  decoration: defaultPinTheme.decoration!.copyWith(
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: focusedBorderColor),
                  ),
                ),
                submittedPinTheme: defaultPinTheme.copyWith(
                  decoration: defaultPinTheme.decoration!.copyWith(
                    color: fillColor,
                    borderRadius: BorderRadius.circular(19),
                    border: Border.all(color: focusedBorderColor),
                  ),
                ),
                errorPinTheme: defaultPinTheme.copyBorderWith(
                  border: Border.all(color: Colors.redAccent),
                ),
              ),
            ),
            const SizedBox(
              height: 4.0,
            ),
            Text(
              verifyOTPProvider.error != null ? verifyOTPProvider.error! : '',
              style: const TextStyle(fontSize: 10.0, color: Colors.red),
            ),
            const SizedBox(
              height: 4.0,
            ),
            CustomElevatedButton(
              buttonText:
                  verifyOTPProvider.isLoading ? 'Loading..' : 'Validate',
              onPress: () {
                focusNode.unfocus();
                if (formKey.currentState!.validate()) {
                  verifyOTPProvider
                      .verifyOTP(
                          mobileNumberProvider.mobileNumber, pinController.text)
                      .then(
                        (value) => {
                          if (value!.success)
                            {
                              Provider.of<UserProvider>(context, listen: false)
                                  .setUser(value.profile!),
                              Navigator.pushNamedAndRemoveUntil(context,
                                  '/home_page', (Route<dynamic> route) => false)
                            }
                          else
                            {
                              ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                      content: Text(verifyOTPProvider
                                          .verifyOtpModel!.message!)))
                            },
                        },
                      );
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
