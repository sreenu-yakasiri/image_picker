import 'package:employee_attendance/ui/components/custom_button.dart';
import 'package:employee_attendance/utils/constants.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../providers/send_otp_provider.dart';
import '../../components/custom_text_field.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  late TextEditingController _controller;
  late String _mobile;
  @override
  Widget build(BuildContext context) {
    SendOTPProvider auth = Provider.of<SendOTPProvider>(context);
    //UserProvider user = Provider.of<UserProvider>(context);

    // void doLogin() {
    //   final Future<OtpModel> successfulMessage = auth.sendOTP(_mobile);
    //   successfulMessage.then((response) {
    //     if (response.success) {
    //       Navigator.pushReplacementNamed(context, '/dashboard');
    //     } else {
    //       debugPrint(response.message);
    //       ScaffoldMessenger.of(context)
    //           .showSnackBar(SnackBar(content: Text(response.message)));
    //     }
    //   });
    // }

    return SafeArea(
        child: Scaffold(
      body: Container(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Expanded(
              child: Center(
                child: Hero(
                  tag: 'appLogo',
                  child: Image(
                      image: AssetImage('assets/images/login_banner.jpeg')),
                ),
              ),
            ),
            // Text(
            //   user.isUserAvailable ? user.userProfile!.name! : '',
            //   style: kHead2TextStyle,
            // ),
            const Text(
              'Login',
              style: kHead2TextStyle,
            ),
            const SizedBox(
              height: 10.0,
            ),
            const Text(
                style: kBodyTextStyle,
                'Continue with your mobile number, will send and OTP to verify'),
            const SizedBox(
              height: 25.0,
            ),
            CustomTextField(
              label: 'Enter Mobile Number',
              hint: 'Mobile Number',
              //error: auth.error,
              onChanged: (String value) {
                _mobile = value;
                debugPrint(_mobile);
              },
            ),
            const SizedBox(
              height: 4.0,
            ),
            Text(
              auth.error != null ? auth.error! : '',
              style: const TextStyle(fontSize: 10.0, color: Colors.red),
            ),
            const SizedBox(
              height: 4.0,
            ),
            CustomElevatedButton(
              buttonText: auth.isLoading ? 'Loading..' : 'Login',
              onPress: () {
                auth.sendOTP(_mobile).then(
                      (value) => {
                        if (value.success)
                          {Navigator.pushNamed(context, '/otp_page')}
                        else
                          {
                            ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text(auth.otpModel.message)))
                          }
                      },
                    );
              },
            )
          ],
        ),
      ),
    ));
  }
}
