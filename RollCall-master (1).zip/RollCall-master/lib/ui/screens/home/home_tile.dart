import 'package:flutter/material.dart';
import '../../../utils/constants.dart';

class HomeTile extends StatelessWidget {
  final String title;
  final Widget icon;
  const HomeTile({super.key, required this.title, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3.0,
      margin: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 0.0),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            icon,
            const SizedBox(
              width: 15.0,
            ),
            Text(
              title,
              style: kTitleTextStyle,
            ),
            const Spacer(),
            const Icon(
              Icons.arrow_forward_ios,
              size: 20,
            ),
          ],
        ),
      ),
    );
  }
}
