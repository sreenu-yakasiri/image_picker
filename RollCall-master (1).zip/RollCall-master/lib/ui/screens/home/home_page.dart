import 'package:employee_attendance/providers/fcm_provider.dart';
import 'package:employee_attendance/providers/user_provider.dart';
import 'package:employee_attendance/ui/screens/home/banners.dart';
import 'package:employee_attendance/ui/screens/home/user_tile.dart';
import 'package:employee_attendance/utils/app_url.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../../utils/constants.dart';
import '../../../utils/notification_services.dart';
import 'check_in_out_card.dart';
import 'menu_attendence_grid.dart';

class HomePage extends StatefulWidget {
  const HomePage({
    super.key,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  NotificationServices notificationServices = NotificationServices();

  checkLocationPermissions() async {
    String userID = context.read<UserProvider>().currentUser.id.toString();

    const platformMethodChannel = MethodChannel('nativeChannel');
    var result =
        await platformMethodChannel.invokeMethod('checkPermissions', userID);
    if (!result) {
      await platformMethodChannel.invokeMethod('method', userID);
    }
  }

  @override
  void initState() {
    super.initState();
    notificationServices.requestNotificationPermission();
    notificationServices.forgroundMessage();
    notificationServices.firebaseInit(context);
    notificationServices.setupInteractMessage(context);
    notificationServices.isTokenRefresh();

    notificationServices.getDeviceToken().then((value) {
      String userID = context.read<UserProvider>().currentUser!.id.toString();
      new FcmProvider().updateFcmToken(value, userID);
      if (kDebugMode) {
        print('device token');
        print(value);
      }
    });

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      checkLocationPermissions();
      //if app is opened from notificaiton
      var page = context.read<UserProvider>().notificationRoutePage;
      ;
      if (AppUrl.leaveType.toLowerCase() == page.toLowerCase()) {
        Provider.of<UserProvider>(context, listen: false)
            .setNotificationRoutePage("");
        Navigator.pushNamed(context, '/applied_leaves');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          elevation: elevation,
          shadowColor: Theme.of(context).shadowColor,
          //backgroundColor: Colors.blueAccent,
          title: const Text(
            AppUrl.appName,
            style: ToolBarTextHeaderStyle,
          ),
          automaticallyImplyLeading: false,
        ),
        body: Padding(
          padding: const EdgeInsets.all(0),
          child: ListView(
            //mainAxisAlignment: MainAxisAlignment.start,
            //crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const UserProfileTile(),
              Transform.translate(
                  offset: const Offset(0, -20), child: const Banners()),
              Transform.translate(
                offset: const Offset(0, -25),
                child: Column(
                  children: [
                    const MenuCard(
                        "Check In/Out",
                        "Seamlessly update your timings, every day.",
                        "assets/images/timings.png",
                        "/check_in_out_page"),
                    const MenuCard(
                        "My Tasks",
                        "Fullfill your Tasks on time, every time.",
                        "assets/images/task_logo.png",
                        "/my_tasks_page"),
                    const MenuItemAttendenceGrid(),
                    const SizedBox(height: 10.0),
                    InkWell(
                        onTap: () async {
                          logOut();
                        },
                        child: Padding(
                          padding: const EdgeInsets.only(bottom: 16.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment
                                .center, //Center Row contents horizontally
                            children: [
                              Icon(
                                Icons.logout,
                                size: 20,
                                color: Colors.redAccent,
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 6.0),
                                child: Text("Logout",
                                    style: SubMenuTitleTextStyle),
                              ),
                            ],
                          ),
                        )

                        /* const HomeTile(
                    title: 'Logout',
                    icon: Icon(
                      Icons.logout,
                      size: 30,
                      color: Colors.redAccent,
                    ),
                  ),*/
                        ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void logOut() {
    context.read<UserProvider>().removeUser();
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Successfully Logged out')));
    Navigator.pushNamedAndRemoveUntil(
        context, '/login_page', (Route<dynamic> route) => false);
  }
}
