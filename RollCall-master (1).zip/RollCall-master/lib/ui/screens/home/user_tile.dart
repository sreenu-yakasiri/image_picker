import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../providers/user_provider.dart';
import '../../../utils/constants.dart';

class UserProfileTile extends StatelessWidget {
  const UserProfileTile({super.key});

  @override
  Widget build(BuildContext context) {
    var user = context.watch<UserProvider>().currentUser;
    return InkWell(
      onTap: (){
        Navigator.pushNamed(context, '/profile_page');
      },
      child: Row(
        children: [
          CachedNetworkImage(
            width: 75,
            height: 75,
            imageUrl: user!.profilePhotoUrl!,
            //placeholder: (context, url) => const CircularProgressIndicator(),
            errorWidget: (context, url, error) => const Icon(
              Icons.person_outlined,
              color: Colors.red,
            ),
          ),

          const SizedBox(
            width: 8.0,
          ),
          Text(
            user.name!.isNotEmpty ? 'Hi, ${user.name!.toUpperCase()}!' : '...',
            style: kTitleTextStyle,
          ),
          //Text(userProvider.userName!)
        ],
      ),
    );
  }
}
