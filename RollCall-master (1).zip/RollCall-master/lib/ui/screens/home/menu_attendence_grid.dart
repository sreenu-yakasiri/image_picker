import 'package:flutter/material.dart';
import '../../../utils/constants.dart';

class MenuItemAttendenceGrid extends StatelessWidget {
  const MenuItemAttendenceGrid({super.key});



  @override
  Widget build(BuildContext context) {

    var attendence_menu_items = ["Holidays","Apply Leave","Available Leaves", "Applied Leaves"];
    var attendence_menu_images = ["assets/images/holidays.png","assets/images/apply_leave.png",
      "assets/images/available_leaves.png", "assets/images/applied_leaves.png"];
    var attendence_menu_nav = ["/holiday_list","/apply_leave","/available_leaves", "/applied_leaves"];

    return  Padding(
      padding: const EdgeInsets.all(8.0),
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(4),
        ),
        child: Column(
          children: [
            Container(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text("Attendence Management",
                    style: MenuTitleTextStyle,
                    textAlign: TextAlign.left,),
                )),
            Padding(
              padding: const EdgeInsets.only(left: 8.0,right: 8.0,top: 8.0,bottom: 16.0),
              child: GridView.count(
                physics: NeverScrollableScrollPhysics(),
                    crossAxisCount: 2,
                    crossAxisSpacing: 10.0,
                    mainAxisSpacing: 10.0,
                    shrinkWrap: true,
                    children: List.generate(attendence_menu_items.length, (index) {
                      return GestureDetector(
                        onTap: (){
                          Navigator.pushNamed(context, attendence_menu_nav[index]);
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(
                              width: 0.3,
                              color: Colors.black,
                            ),
                          ),
                          padding: const EdgeInsets.all(10.0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center, //Center Column contents vertically,
                            children: [
                              Image.asset(attendence_menu_images[index],
                                height: 80,
                                width: 80),
                              Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Text(attendence_menu_items[index], style: SubMenuTitleTextStyle),
                              ),
                            ],
                          ),
                          ),
                      );
                    },),
                  ),
            ),
          ],
        ),
      ),
    );
  }
}

