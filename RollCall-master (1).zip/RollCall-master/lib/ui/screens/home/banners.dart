import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../providers/banners_provider.dart';

class Banners extends StatefulWidget {
  const Banners({super.key});

  @override
  State<Banners> createState() => _BannersState();
}

class _BannersState extends State<Banners> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    context.read<BannersProvider>().getBanners(context);
  }

  @override
  Widget build(BuildContext context) {
    final bannersProvider = context.watch<BannersProvider>();
    return Container(
      child: SizedBox(
          height: 250,
          child:
              bannersProvider.isLoading ? null : bannersView(bannersProvider)),
    );
  }

  bannersView(BannersProvider bannersProvider) {
    return CarouselSlider(
      options: CarouselOptions(
        height: 250.0,
        autoPlay: true,
        autoPlayInterval: const Duration(seconds: 4),
        enableInfiniteScroll: true,
      ),
      items: bannersProvider.bannersModel!.banners?.map((i) {
        int idx = bannersProvider.bannersModel!.banners!.indexOf(i);
        return Builder(
          builder: (BuildContext context) {
            return Container(
                width: MediaQuery.of(context).size.width,
                margin: EdgeInsets.symmetric(horizontal: 3.0),
                decoration: BoxDecoration(color: Colors.transparent),
                child: Image.network(
                    (bannersProvider.bannersModel!.banners![idx].path) ?? ""));
          },
        );
      }).toList(),
    );
  }
}
