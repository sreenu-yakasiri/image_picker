import 'package:employee_attendance/models/applied_leaves_model.dart';
import 'package:employee_attendance/models/holidays_list_model.dart';
import 'package:employee_attendance/providers/applied_leaves_provider.dart';
import 'package:employee_attendance/providers/holidays_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../utils/constants.dart';
import '../../providers/user_provider.dart';

class HolidayListPage extends StatefulWidget {
  const HolidayListPage({super.key});
  @override
  State<HolidayListPage> createState() => _HolidayListPagePageState();
}

class _HolidayListPagePageState extends State<HolidayListPage> {
  late Future<HolidaysListModel> holidaysListModel;

  @override
  void initState() {
    super.initState();
    holidaysListModel = HolidaysProvider.getHolidays(
        context.read<UserProvider>().currentUser!.tenantId.toString());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: elevation,
        shadowColor: Theme.of(context).shadowColor,
        leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: const Icon(Icons.arrow_back)),
        title: const Text(
          'Holidays',
          style: kHead3TextStyle,
        ),
        automaticallyImplyLeading: false,
      ),
      body: FutureBuilder<HolidaysListModel>(
          future: holidaysListModel,
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              if (snapshot.data!.success) {
                if (snapshot.data!.holidatList!.isNotEmpty) {
                  return ListView.builder(
                    padding: const EdgeInsets.all(16.0),
                    itemCount: snapshot.data!.holidatList?.length,
                    itemBuilder: (BuildContext context, int index) {
                      return Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              snapshot.data!.holidatList[index]!.name,
                              style: kHead3TextStyle,
                            ),
                            Text(
                              snapshot.data!.holidatList[index].date.toString(),
                              style: kHead3TextStyle,
                            ),
                            const Divider(color: Colors.black12)
                          ],
                        ),
                      );
                    },
                  );
                } else {
                  return const Center(
                    child: Text(
                      'No Holidays Data',
                      style: kHead3TextStyle,
                    ),
                  );
                }
              }
            } else if (snapshot.hasError) {
              return Text('${snapshot.error}');
            }
            return const Center(child: CircularProgressIndicator());
          }),
    );
  }
}
