import 'package:employee_attendance/models/applied_leaves_model.dart';
import 'package:employee_attendance/models/available_leaves_model.dart';
import 'package:employee_attendance/providers/applied_leaves_provider.dart';
import 'package:employee_attendance/providers/available_leaves_provider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../providers/user_provider.dart';
import '../../../utils/constants.dart';

class AvailableLeavesPage extends StatefulWidget {
  const AvailableLeavesPage({super.key});
  @override
  State<AvailableLeavesPage> createState() => _AvailableLeavesPageState();
}

class _AvailableLeavesPageState extends State<AvailableLeavesPage> {
  late Future<AvailableLeavesModel> dataModel;

  @override
  void initState() {
    super.initState();
    dataModel = AvailableLeavesProvider.getAvailableLeaves(
        context.read<UserProvider>().currentUser!.id.toString());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: elevation,
        shadowColor: Theme.of(context).shadowColor,
        leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: const Icon(Icons.arrow_back)),
        title: const Text(
          'Available Leaves',
          style: kHead3TextStyle,
        ),
        automaticallyImplyLeading: false,
      ),
      body: FutureBuilder<AvailableLeavesModel>(
          future: dataModel,
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              if (snapshot.data!.success) {
                if (snapshot.data!.availableLeaveList.isNotEmpty) {
                  return ListView.builder(
                    padding: const EdgeInsets.all(16.0),
                    itemCount: snapshot.data!.availableLeaveList.length,
                    itemBuilder: (BuildContext context, int index) {
                      return Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              snapshot.data!.availableLeaveList[index].leave,
                              style: kHead3TextStyle,
                            ),
                            Text(
                              snapshot.data!.availableLeaveList[index].count.toString(),
                              style: kHead3TextStyle,
                            ),
                            const Divider(color: Colors.black12)
                          ],
                        ),
                      );
                    },
                  );
                }
                else{
                  return const Center(
                    child: Text('Data not available!', style: kHead3TextStyle,),
                  );
                }
              }
            } else if (snapshot.hasError) {
              return Text('${snapshot.error}');
            }
            return const Center(child: CircularProgressIndicator());
          }),
    );
  }
}
