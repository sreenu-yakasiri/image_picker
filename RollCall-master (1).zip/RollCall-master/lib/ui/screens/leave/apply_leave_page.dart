import 'package:employee_attendance/models/leave_types_model.dart';
import 'package:employee_attendance/providers/leave_types_provider.dart';
import 'package:employee_attendance/providers/user_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../providers/apply_leave_provider.dart';
import '../../../utils/constants.dart';
import '../../components/custom_button.dart';

class ApplyLeavePage extends StatefulWidget {
  const ApplyLeavePage({super.key});

  @override
  State<ApplyLeavePage> createState() => _ApplyLeavePageState();
}

class _ApplyLeavePageState extends State<ApplyLeavePage> {
  DateTime _startDate = DateTime.now();
  DateTime _endDate = DateTime.now();
  String leaveType = 'Select Leave Type';
  String? leaveTypeID;
  late Future<LeaveTypesModel> leaveTypesModel;

  Future<void> _selectDate(BuildContext context, bool isToDate) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: _startDate,
        firstDate: DateTime(2015, 8),
        lastDate: DateTime(2101));
    if (picked != null) {
      setState(() {
        if (isToDate) {
          _startDate = picked;
        } else {
          _endDate = picked;
        }
      });
    }
  }

  @override
  void initState() {
    super.initState();
    leaveTypesModel = LeaveTypesProvider.getLeaveTypes();
  }

  @override
  Widget build(BuildContext context) {
    ApplyLeaveProvider applyLeaveProvider =
        Provider.of<ApplyLeaveProvider>(context);
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          elevation: elevation,
          shadowColor: Theme.of(context).shadowColor,
          leading: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: const Icon(Icons.arrow_back)),
          title: const Text(
            'Apply Leave',
            style: kHead3TextStyle,
          ),
          automaticallyImplyLeading: false,
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text(
                'Leave type',
                style: kHead3TextStyle,
              ),
              const SizedBox(
                height: 8.0,
              ),
              OutlinedButton(
                onPressed: () {
                  showLeaveTypesBottomSheet(context);
                },
                child: Text(leaveType),
              ),
              const SizedBox(
                height: 8.0,
              ),
              const SizedBox(
                height: 20,
              ),
              const Text(
                'Start Date',
                style: kHead3TextStyle,
              ),
              const SizedBox(
                height: 8.0,
              ),
              OutlinedButton(
                onPressed: () => _selectDate(context, true),
                child: Text("${_startDate.toLocal()}".split(' ')[0]),
              ),
              const SizedBox(
                height: 20,
              ),
              const Text(
                'End Date',
                style: kHead3TextStyle,
              ),
              const SizedBox(
                height: 8,
              ),
              OutlinedButton(
                onPressed: () => _selectDate(context, false),
                child: Text("${_endDate.toLocal()}".split(' ')[0]),
              ),
              const SizedBox(
                height: 20,
              ),
              const Spacer(),
              CustomElevatedButton(
                buttonText:
                    applyLeaveProvider.isLoading ? 'Applying..' : 'Apply Leave',
                onPress: () {
                  if (applyLeaveProvider.isLoading) {
                    return null;
                  }
                  String userID =
                      context.read<UserProvider>().currentUser!.id.toString();
                  applyLeaveProvider
                      .applyLeave(
                          "${_startDate.toLocal()}".split(' ')[0],
                          "${_endDate.toLocal()}".split(' ')[0],
                          leaveTypeID,
                          userID)
                      .then(
                        (value) => {
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              content: value is String
                                  ? Text(value)
                                  : Text(value['message']))),
                        },
                      );
                },
              )
            ],
          ),
        ),
      ),
    );
  }

  Future<void> showLeaveTypesBottomSheet(BuildContext context) {
    return showModalBottomSheet<void>(
      context: context,
      builder: (BuildContext context) {
        return Column(
          children: [
            const SizedBox(
              height: 16,
            ),
            const Text(
              'Leave Type\'s',
              style: kHead2TextStyle,
            ),
            SizedBox(
              height: 200,
              child: FutureBuilder<LeaveTypesModel>(
                future: leaveTypesModel,
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    if (snapshot.data!.success) {
                      return ListView.builder(
                        padding: const EdgeInsets.all(16.0),
                        itemCount: snapshot.data!.leaveType.length,
                        itemBuilder: (BuildContext context, int index) {
                          return InkWell(
                            onTap: () {
                              setState(() {
                                leaveType =
                                    snapshot.data!.leaveType[index].name;
                                leaveTypeID = snapshot.data!.leaveType[index].id
                                    .toString();
                                Navigator.pop(context);
                              });
                            },
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                snapshot.data!.leaveType[index].name,
                                style: kHead3TextStyle,
                              ),
                            ),
                          );
                        },
                      );
                    }
                  } else if (snapshot.hasError) {
                    return Text('${snapshot.error}');
                  }
                  // By default, show a loading spinner.
                  return const CircularProgressIndicator();
                },
              ),
            ),
          ],
        );
      },
    );
  }
}
