import 'package:employee_attendance/models/applied_leaves_model.dart';
import 'package:employee_attendance/providers/applied_leaves_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../providers/user_provider.dart';
import '../../../utils/constants.dart';

class AppliedLeavesPage extends StatefulWidget {
  const AppliedLeavesPage({super.key});
  @override
  State<AppliedLeavesPage> createState() => _AppliedLeavesPageState();
}

class _AppliedLeavesPageState extends State<AppliedLeavesPage> {
  late Future<AppliedLeavesModel> appliedLeavesModel;

  @override
  void initState() {
    super.initState();
    appliedLeavesModel = AppliedLeavesProvider.getAppliedLeaves(
        context.read<UserProvider>().currentUser!.id.toString());
  }

  getLeaveText(String? from, String? to) {
    if (from == to) {
      return "Leave on $from";
    } else {
      return "Leave from : $from to $to";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: elevation,
        shadowColor: Theme.of(context).shadowColor,
        leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: const Icon(Icons.arrow_back)),
        title: const Text(
          'Leaves',
          style: kHead3TextStyle,
        ),
        automaticallyImplyLeading: false,
      ),
      body: FutureBuilder<AppliedLeavesModel>(
          future: appliedLeavesModel,
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              if (snapshot.data!.success == true) {
                if (snapshot.data!.leaveData!.isNotEmpty) {
                  return ListView.builder(
                    padding: const EdgeInsets.all(16.0),
                    itemCount: snapshot.data!.leaveData!.length,
                    itemBuilder: (BuildContext context, int index) {
                      return Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Leave Status : ${snapshot.data!.leaveData![index].leaveStatus}',
                              style: kHead3TextStyle,
                            ),
                            Text(
                              getLeaveText(
                                  snapshot!.data!.leaveData![index].fromDate,
                                  snapshot!.data!.leaveData![index].toDate),
                              style: kHead3TextStyle,
                            ),
                            Row(
                              children: [
                                Text(
                                  'Leave Id : ${snapshot.data!.leaveData![index].id}',
                                  style: kBodyTextStyle,
                                ),
                                const SizedBox(
                                  width: 20,
                                ),
                                Text(
                                  'Leave Type : ${snapshot.data!.leaveData![index].leaveTypeName}',
                                  style: kBodyTextStyle,
                                ),
                              ],
                            ),
                            const Divider(color: Colors.black12)
                          ],
                        ),
                      );
                    },
                  );
                } else {
                  return const Center(
                    child: Text(
                      'No Leaves Yet!',
                      style: kHead3TextStyle,
                    ),
                  );
                }
              }
            } else if (snapshot.hasError) {
              return Text('${snapshot.error}');
            }
            return const Center(child: CircularProgressIndicator());
          }),
    );
  }
}
