import 'dart:async';

import 'package:employee_attendance/models/user_profile.dart';
import 'package:employee_attendance/providers/user_provider.dart';
import 'package:employee_attendance/utils/constants.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../utils/shared_prepherence.dart';

class WelcomePage extends StatefulWidget {
  const WelcomePage({super.key});

  @override
  State<WelcomePage> createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {
  @override
  void initState() {
    super.initState();
    getUserData();
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FlutterLogo(
              size: 50,
            ),
            SizedBox(
              height: 20,
            ),
            Text(
              'Welcome',
              style: kHead1TextStyle,
            )
          ],
        ),
      ),
    );
    // return Scaffold(
    //   body: FutureBuilder(
    //     future: Preferences.getStringFromSp('user_profile_json'),
    //     builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
    //       late List<Widget> children;
    //       if (snapshot.hasData) {
    //         userProvider.getUserDetails(snapshot.data);
    //         Timer(const Duration(seconds: 3), () {
    //           if (userProvider.isUserAvailable) {
    //             Navigator.pushNamed(context, '/home_page');
    //           } else {
    //             Navigator.pushNamed(context, '/login_page');
    //           }
    //         });
    //       } else if (snapshot.hasError) {
    //         children = <Widget>[];
    //         debugPrint(snapshot.error.toString());
    //       } else {
    //         children = <Widget>[
    //           const FlutterLogo(
    //             size: 50,
    //           ),
    //           const SizedBox(
    //             height: 20,
    //           ),
    //           const Text(
    //             'Welcome',
    //             style: kHead1TextStyle,
    //           )
    //         ];
    //       }
    //       return Center(
    //         child: Column(
    //           mainAxisAlignment: MainAxisAlignment.center,
    //           children: children,
    //         ),
    //       );
    //     },
    //   ),
    // );
  }

  void getUserData() async {
    UserProfile? userProfile;
    try {
      var userJson = await Preferences.getStringFromSp('user_profile_json');
      Timer(const Duration(seconds: 3), () {
        if (userJson != null) {
          userProfile = userprofileFromJson(userJson.toString());
          if(userProfile?.id != null) {
            Provider.of<UserProvider>(context, listen: false).setUser(userProfile!);
            Navigator.pushNamed(context, '/home_page');
          }
        } else {
          Navigator.pushNamed(context, '/login_page');
        }
      });
    } catch (e) {
      debugPrint(e.toString());
    }
  }
}
