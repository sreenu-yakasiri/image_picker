import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/user_provider.dart';
import '../../utils/constants.dart';

class MyProfile extends StatefulWidget {
  const MyProfile({super.key});

  @override
  State<MyProfile> createState() => _MyProfileState();
}

class _MyProfileState extends State<MyProfile> {
  var name = TextEditingController();
  var email = TextEditingController();
  var mobile = TextEditingController();
  var org = TextEditingController();
  @override
  Widget build(BuildContext context) {
    var user = context.watch<UserProvider>().currentUser;
    name.text = user.name ?? '';
    email.text = user.email ?? '';
    mobile.text = user.mobile ?? '';
    org.text = user.organizationName ?? '';
    return Scaffold(
      appBar: AppBar(
          elevation: elevation,
          shadowColor: Theme.of(context).shadowColor,
          title: const Text(
            'My Profile',
            style: kHead3TextStyle,
          )),
      body: Padding(
        padding: const EdgeInsets.only(bottom: 16.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: CachedNetworkImage(
                  width: 75,
                  height: 75,
                  imageUrl:
                      user.profilePhotoUrl == null ? '' : user.profilePhotoUrl!,
                  //placeholder: (context, url) => const CircularProgressIndicator(),
                  errorWidget: (context, url, error) => const Icon(
                    Icons.person_outlined,
                    color: Colors.red,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16.0, right: 16.0),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(bottom: 16.0),
                      child: TextField(
                        readOnly: true,
                        controller: name,
                        decoration: const InputDecoration(
                            border: OutlineInputBorder(), label: Text('Name')),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 16.0),
                      child: TextField(
                        readOnly: true,
                        controller: email,
                        decoration: const InputDecoration(
                            border: OutlineInputBorder(), label: Text('email')),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 16.0),
                      child: TextField(
                        readOnly: true,
                        controller: mobile,
                        decoration: const InputDecoration(
                            border: OutlineInputBorder(),
                            label: Text('mobile')),
                      ),
                    ),
                    Visibility(
                      visible: user.organizationName != null,
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 16.0),
                        child: TextField(
                          readOnly: true,
                          controller: org,
                          decoration: InputDecoration(
                              border: const OutlineInputBorder(),
                              label: Text(user.organizationName ?? '')),
                        ),
                      ),
                    ),
                    Visibility(
                      visible: false,
                      child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            minimumSize: const Size.fromHeight(50), // NEW
                          ),
                          onPressed: () {},
                          child: const Text("Submit")),
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
