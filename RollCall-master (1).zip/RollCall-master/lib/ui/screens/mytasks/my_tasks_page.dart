import 'package:employee_attendance/providers/DataProvider.dart';
import 'package:employee_attendance/ui/screens/mytasks/task_details_page.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../providers/BottomNavigationBarProvider.dart';
import '../../../providers/list_controller.dart';
import '../../../providers/task_details_provider.dart';
import '../../../providers/user_provider.dart';
import '../../../utils/app_url.dart';
import '../../../utils/constants.dart';
import '../../components/common-widgets.dart';

class MyTasksPage extends StatelessWidget {
  const MyTasksPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          elevation: elevation,
          shadowColor: Theme.of(context).shadowColor,
          leading: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: const Icon(Icons.arrow_back)),
          title: const Text(
            'My Tasks',
            style: kHead3TextStyle,
          ),
        ),
        body: BottomNavigationBarExample(key: UniqueKey()));
  }
}

class BottomNavigationBarExample extends StatefulWidget {
  const BottomNavigationBarExample({super.key});

  @override
  State<BottomNavigationBarExample> createState() =>
      _BottomNavigationBarExampleState();
}

class _BottomNavigationBarExampleState
    extends State<BottomNavigationBarExample> {
  //int _selectedIndex = 0;

  List<Widget> _widgetOptions = <Widget>[
    ChangeNotifierProvider<ListController>(
      create: (_) => ListController(),
      child: Tasklist(key: UniqueKey(), AppUrl.activeTaskList),
    ),
    ChangeNotifierProvider<ListController>(
      create: (_) => ListController(),
      child: Tasklist(key: UniqueKey(), AppUrl.completeTaskList),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Consumer<BottomNavigationBarProvider>(
      builder: (context, model, child) => Scaffold(
        body: IndexedStack(
          index: model.currentIndex,
          children: _widgetOptions,
        ),
        bottomNavigationBar: BottomNavigationBar(
          elevation: 10,
          backgroundColor: Colors.pink,
          //shadowColor: Theme.of(context).shadowColor,
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(Icons.task),
              label: 'Active',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.done),
              label: 'Completed',
            )
          ],
          currentIndex: model.currentIndex,
          selectedItemColor: Colors.white,
          onTap: (index) {
            model.currentIndex = index;
            //model.currentIndex(index);
          },
        ),
      ),
    );
  }
}

class Tasklist extends StatefulWidget {
  final String url;

  const Tasklist(this.url, {key}) : super(key: key);

  @override
  State<Tasklist> createState() => _TasklistState(url);
}

class _TasklistState extends State<Tasklist> {
  late String _baseUrl;

  _TasklistState(String url) {
    _baseUrl = url;
  }
  CommonWidgets commonWidgets = CommonWidgets();
  // The controller for the ListView
  //late ScrollController _controller;

  @override
  void initState() {
    super.initState();
    //_controller = ScrollController(initialScrollOffset: 0)..addListener(_loadMore);
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      getListFromApi();
    });
  }

  getListFromApi() {
    if (_baseUrl == AppUrl.activeTaskList) {
      context.read<ListController>().getTasks(
          _baseUrl,
          context.read<UserProvider>().currentUser!.id.toString(),
          context.read<UserProvider>().currentUser!.authToken.toString());
    } else {
      context.read<ListController>().getCompletedTasks(
          _baseUrl,
          context.read<UserProvider>().currentUser!.id.toString(),
          context.read<UserProvider>().currentUser!.authToken.toString());
    }
  }

  getProjectName(String projectName) {
    if (projectName != null && projectName != "") {
      return "\n" + "Project name : " + projectName;
    }

    return "";
  }

  /*_loadMore(){
    //var isLoadApi = context.read<ListController>().loadMore(_controller.position.extentAfter);
    var isLoadApi = context.read<ListController>().loadMore(_controller.position.extentAfter);
    if(isLoadApi)
    {
      //call list api

    }
  }*/

  @override
  void didUpdateWidget(covariant Tasklist oldWidget) {
    //_loadMore();
    super.didUpdateWidget(oldWidget);
  }

  @override
  void dispose() {
    //_controller.removeListener(_loadMore);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ListController>(
      builder: (context, model, child) => Scaffold(
        body: model.isLoading
            ? commonWidgets.circularProgressIndicator()
            : model.activeTasks?.data?.length == 0
                ? Center(child: Text('No data.'))
                : Column(
                    children: [
                      Expanded(
                        child: ListView.builder(
                          //controller: _controller,
                          itemCount: model.activeTasks?.data?.length,
                          itemBuilder: (_, index) => Card(
                            elevation: elevation,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(cardRadius),
                            ),
                            margin: const EdgeInsets.symmetric(
                                vertical: 8, horizontal: 16),
                            child: ListTile(
                              leading: Icon(Icons.task,
                                  color: Theme.of(context).iconTheme.color),
                              title: Text(
                                model.activeTasks?.data?[index].name ?? "",
                                style: new CommonWidgets().titleFontStyle(),
                              ),
                              subtitle: Padding(
                                padding: const EdgeInsets.only(top: 8.0),
                                child: Text("Added on : " +
                                    (model.activeTasks?.data?[index]
                                            .taskAllocateDate ??
                                        "") +
                                    "\n" +
                                    "Task Type : " +
                                    (model.activeTasks?.data?[index]
                                            .taskTypeName ??
                                        "") +
                                    "\n" +
                                    "Task Status : " +
                                    (model.activeTasks?.data?[index]
                                            .taskStatusValue ??
                                        "") +
                                    getProjectName(model.activeTasks
                                            ?.data?[index].projectName ??
                                        "")),
                              ),
                              trailing: const Icon(Icons.arrow_right),
                              onTap: () {
                                context.read<DataProvider>().setTaskData(
                                    model.activeTasks?.data?[index] ?? null);
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        ChangeNotifierProvider<
                                            TaskDetailsProvider>(
                                      create: (_) => TaskDetailsProvider(),
                                      child: TaskDetailsPage(),
                                    ),
                                  ),
                                ).then((value) {
                                  if (context
                                      .read<DataProvider>()
                                      .isRefreshTaskList) {
                                    context
                                        .read<DataProvider>()
                                        .isRefreshTaskList = false;
                                    getListFromApi();
                                  }
                                });
                                ;
                              },
                            ),
                          ),
                        ),
                      ),

                      /* if (model.activeTasks.data?.length == 0)
              Text("No data"),*/
                      // when the _loadMore function is running
                      /*   if (model.isLoadMoreRunning == true)
              Padding(
                padding: EdgeInsets.only(top: 5, bottom: 5),
                child:commonWidgets.circularProgressIndicator(),
              ),*/

                      // When nothing else to load
                      /*if (model.hasNextPage == false)
              Container(
                padding: const EdgeInsets.only(top: 30, bottom: 40),
                color: Colors.amber,
                child: Center(
                  child: Text('You have fetched all of the content'),
                ),
              ),*/
                    ],
                  ),
      ),
    );
  }
}
