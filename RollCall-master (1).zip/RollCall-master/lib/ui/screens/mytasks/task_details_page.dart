import 'dart:io';

import 'package:employee_attendance/providers/DataProvider.dart';
import 'package:employee_attendance/utils/app_url.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../../models/api_response_model.dart';
import '../../../models/image_model.dart';
import '../../../providers/task_details_provider.dart';
import '../../../providers/user_provider.dart';
import '../../../utils/constants.dart';
import '../../components/common-widgets.dart';
import 'image_view.dart';

class TaskDetailsPage extends StatefulWidget {
  const TaskDetailsPage({super.key});

  @override
  State<TaskDetailsPage> createState() => _TaskDetailsPageState();
}

class _TaskDetailsPageState extends State<TaskDetailsPage> {
  //late Data taskDetails;
  final messageController = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      var taskDetails = context.read<DataProvider>().taskData!;
      messageController.text = taskDetails?.message ?? "";
      if (taskDetails?.documents != null) {
        //for (var item in taskDetails!.documents) {
        for (var i = 0; i < taskDetails.documents!.length; i++) {
          context
              .read<TaskDetailsProvider>()
              .addImageToList(taskDetails.documents![i].path);
        }
      }

      if (taskDetails == null) {
        Navigator.pop(context);
      }
    });
  }

  @override
  Widget build(BuildContext buildContext) {
    return Scaffold(
      appBar: AppBar(
        leading: InkWell(
            onTap: () {
              Navigator.pop(context);
            },
            child: const Icon(Icons.arrow_back)),
        elevation: elevation,
        shadowColor: Theme.of(context).shadowColor,
        title: const Text(
          'Task Details',
          style: kHead3TextStyle,
        ),
        //title: const Text('Task Details'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Consumer<TaskDetailsProvider>(
            builder: (providerContext, model, child) => Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Card(
                  elevation: elevation,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(cardRadius),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(context.read<DataProvider>().taskData?.name ?? "",
                            style:
                                new CommonWidgets().titleFontStyle()), //title
                        Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: Text(context
                                  .read<DataProvider>()
                                  .taskData
                                  ?.description ??
                              ""),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: Text("Task Status : " +
                                  context
                                      .read<DataProvider>()
                                      .taskData!
                                      .taskStatusValue
                                      .toString() ??
                              ""),
                        ),
                        Visibility(
                          visible: context
                                  .read<DataProvider>()
                                  .taskData!
                                  .projectName !=
                              null,
                          child: Padding(
                            padding: const EdgeInsets.only(top: 8.0),
                            child: Text("Project name : " +
                                    context
                                        .read<DataProvider>()
                                        .taskData!
                                        .projectName
                                        .toString() ??
                                ""),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: Text("Added on : " +
                              context
                                  .read<DataProvider>()
                                  .taskData!
                                  .taskAllocateDate
                                  .toString()),
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: Card(
                      elevation: elevation,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(cardRadius),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Upload",
                                style: new CommonWidgets().titleFontStyle()),
                            SizedBox(
                              height: 150,
                              child: Padding(
                                padding: const EdgeInsets.only(top: 16.0),
                                child: model.uploadedImage.length == 0
                                    ? Image.asset(
                                        "assets/images/no_image_selected.png",
                                        height: 120,
                                        width: 200)
                                    : ListView.builder(
                                        scrollDirection: Axis.horizontal,
                                        itemCount: model.uploadedImage.length,
                                        itemBuilder: (context, index) {
                                          return GestureDetector(
                                            child: Padding(
                                                padding: const EdgeInsets.only(
                                                    right: 16.0),
                                                child: Stack(
                                                  alignment: Alignment.topRight,
                                                  children: <Widget>[
                                                    if (!model
                                                        .uploadedImage[index]!
                                                        .contains("http")) ...[
                                                      Container(
                                                        decoration:
                                                            new BoxDecoration(
                                                                color: Colors
                                                                    .white),
                                                        child: Image.file(File(
                                                            model.uploadedImage[
                                                                index]!)),
                                                      ),
                                                    ] else ...[
                                                      Container(
                                                        decoration:
                                                            new BoxDecoration(
                                                                color: Colors
                                                                    .white),
                                                        child: Image.network(
                                                            model.uploadedImage[
                                                                index]!),
                                                      ),
                                                    ],
                                                    Align(
                                                      alignment:
                                                          Alignment.topRight,
                                                      child: Card(
                                                        elevation: 20,
                                                        shape:
                                                            RoundedRectangleBorder(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      150),
                                                        ),
                                                        child: GestureDetector(
                                                          child: Container(
                                                              decoration: new BoxDecoration(
                                                                  shape: BoxShape
                                                                      .circle,
                                                                  color: Colors
                                                                      .white),
                                                              child: Icon(
                                                                  Icons.close)),
                                                          onTap: () {
                                                            if (context
                                                                    .read<
                                                                        DataProvider>()
                                                                    .taskData!
                                                                    .taskStatus !=
                                                                AppUrl
                                                                    .TASK_COMPLETE_ID) {
                                                              //perform action when task status is not completed
                                                              if (model
                                                                  .uploadedImage[
                                                                      index]!
                                                                  .contains(
                                                                      "http")) {
                                                                ApiResponseModel result = model.deleteImage(
                                                                    context,
                                                                    context
                                                                        .read<
                                                                            DataProvider>()
                                                                        .taskData!
                                                                        .documents![
                                                                            index]
                                                                        .id
                                                                        .toString(),
                                                                    index) as ApiResponseModel;
                                                              } else {
                                                                model
                                                                    .removeImageToList(
                                                                        index);
                                                              }
                                                            }
                                                          },
                                                        ),
                                                      ),
                                                    )
                                                  ],
                                                )),
                                            onTap: () {
                                              Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context1) =>
                                                        ImageView(
                                                            model.uploadedImage[
                                                                index]!)),
                                              );
                                            },
                                          );
                                        },
                                      ),
                              ),
                            ),
                            Visibility(
                              visible: context
                                      .read<DataProvider>()
                                      .taskData!
                                      .taskStatus !=
                                  AppUrl.TASK_COMPLETE_ID,
                              child: Container(
                                margin: const EdgeInsets.fromLTRB(0, 16, 0, 0),
                                child: ElevatedButton(
                                    onPressed: () {
                                      if (model.uploadedImage.length >= 5) {
                                        new CommonWidgets().showSnackbar(
                                            "Only 5 images can be uploaded.",
                                            context);
                                      } else {
                                        _showSimpleDialog(context);
                                      }
                                    },
                                    style: ElevatedButton.styleFrom(
                                        fixedSize: const Size(150, 50)),
                                    child: const Text('Upload Images')),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 16.0),
                              child: TextField(
                                keyboardType: TextInputType.multiline,
                                maxLines: 4,
                                controller: messageController,
                                decoration: InputDecoration(
                                  border: OutlineInputBorder(),
                                  hintText: 'Message',
                                ),
                              ),
                            ),
                          ],
                        ),
                      )),
                ),
                Visibility(
                  visible: context.read<DataProvider>().taskData!.taskStatus !=
                      AppUrl.TASK_COMPLETE_ID,
                  child: Padding(
                    padding: const EdgeInsets.only(top: 16, left: 4, right: 4),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        minimumSize: const Size.fromHeight(50), // NEW
                      ),
                      onPressed: model.isLoading
                          ? null
                          : () {
                              if (context
                                      .read<DataProvider>()
                                      .taskData!
                                      .taskStatus !=
                                  AppUrl.TASK_COMPLETE_ID) {
                                //perform action when task status is not completed
                                if (messageController.text == null ||
                                    messageController.text == "") {
                                  new CommonWidgets().showSnackbar(
                                      "Please provide message", context);
                                } else {
                                  model.isLoading = true;
                                  var images = model.uploadedImage;
                                  List<String> uploadImages = [];
                                  for (int i = 0; i < images.length; i++) {
                                    if (!images[i]!.contains("http") &&
                                        images[i] != null)
                                      uploadImages.add(images[i]!);
                                  }
                                  model.uploadImagesApi(
                                      buildContext,
                                      uploadImages,
                                      messageController.text,
                                      context
                                          .read<DataProvider>()
                                          .taskData!
                                          .id!
                                          .toString(),
                                      buildContext
                                          .read<UserProvider>()
                                          .currentUser!
                                          .id
                                          .toString());
                                }
                              }
                            },
                      child: Text(
                        model.buttonName,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _showSimpleDialog(BuildContext mainContext) async {
    await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return SimpleDialog(
            // <-- SEE HERE
            title: const Text('Choose'),
            children: <Widget>[
              SimpleDialogOption(
                onPressed: () {
                  Navigator.pop(context);
                  var image = pickImage();
                  image.then((path) {
                    debugPrint('path:  $path');
                    var file = new ImageModel(path, null);
                    if (file.localImage != null) {
                      debugPrint('path:  ' + file.localImage!.path ?? "");
                      mainContext
                          .read<TaskDetailsProvider>()
                          .addImageToList(file.localImage?.path ?? "");
                    }
                  });
                },
                child: const Text('Gallery/Photos'),
              ),
              SimpleDialogOption(
                onPressed: () {
                  Navigator.pop(context);
                  var image = pickFromCamera();
                  image.then((path) {
                    var file = new ImageModel(path, null);
                    if (file.localImage != null) {
                      mainContext
                          .read<TaskDetailsProvider>()
                          .addImageToList(file.localImage?.path ?? "");
                    }
                  });
                },
                child: const Text('Camera'),
              ),
            ],
          );
        });
  }

  File? image;
  Future<XFile?> pickImage() async {
    try {
      final ImagePicker picker = ImagePicker();
      final XFile? image = await picker.pickImage(source: ImageSource.gallery);
      return image;
    } on PlatformException catch (e) {
      print('Failed to pick image: $e');
    }
  }

  Future<XFile?> pickFromCamera() async {
    try {
      final ImagePicker picker = ImagePicker();
      final XFile? image = await picker.pickImage(source: ImageSource.camera);
      return image;
    } on PlatformException catch (e) {
      print('Failed to pick image: $e');
    }
  }
}
