
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CommonWidgets{
  Widget circularProgressIndicator(){
    return  Center(
      child: Transform.scale(
        scale: 0.5,
        child: CircularProgressIndicator(),
      ),
    );
  }

  TextStyle titleFontStyle(){
    return   TextStyle(fontSize: 18, fontWeight: FontWeight.bold);
  }

  TextStyle regularFontStyle(){
    return   TextStyle();
  }

  showSnackbar(String message, BuildContext context)
  {
    var snackBar = SnackBar(
      content: Text(message),
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }
}

