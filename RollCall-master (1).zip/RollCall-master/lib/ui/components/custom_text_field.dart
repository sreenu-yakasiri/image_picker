import 'package:flutter/material.dart';

class CustomTextField extends StatelessWidget {
  final String label;
  final String? hint;
  final String? error;
  final ValueChanged<String>? onChanged;
  const CustomTextField({super.key, required this.label, this.hint, required this.onChanged, this.error});

  @override
  Widget build(BuildContext context) {
    return TextField(
      maxLines: 1,
      keyboardType: TextInputType.number,
      autofocus: false,
      onChanged: onChanged,
      decoration: InputDecoration(
        border: const OutlineInputBorder(),
        hintText: hint,
        labelText: label,
        errorText: error
      ),
    );
  }
}
