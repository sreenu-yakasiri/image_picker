import 'package:flutter/material.dart';

var loading = const Row(
  mainAxisAlignment: MainAxisAlignment.center,
  children: <Widget>[
    CircularProgressIndicator(),
    Text(" Authenticating ... Please wait")
  ],
);