
import 'dart:convert';

UserProfile userprofileFromJson(String str) =>
    UserProfile.fromJson(json.decode(str));

String userProfileToJson(UserProfile data) => json.encode(data.toJson());


class UserProfile {
  final int? id;
  final String? name;
  final String? email;
  final dynamic emailVerifiedAt;
  final String? mobile;
  final dynamic country;
  final dynamic countryCode;
  final dynamic currentTeamId;
  final dynamic profilePhotoPath;
  final int? roleId;
  final String? state;
  final String? city;
  final String? pincodes;
  final int? status;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final int? tour;
  final int? createdBy;
  final int? isOrganization;
  final dynamic organizationName;
  final dynamic gstNo;
  final dynamic bankName;
  final dynamic vendorType;
  final dynamic accountNo;
  final dynamic ifscCode;
  final dynamic panCard;
  final dynamic billingAddress;
  final int? organizationId;
  final String? tenantId;
  final int? isTeamLead;
  final int? isLap;
  final int? isDemo;
  final int? employeeType;
  final dynamic aadharNo;
  final int? isFontendVendor;
  final String? reference;
  final dynamic deviceId;
  final dynamic fcmId;
  final String? authToken;
  final String? profilePhotoUrl;

  UserProfile({
    this.id,
    this.name,
    this.email,
    this.emailVerifiedAt,
    this.mobile,
    this.country,
    this.countryCode,
    this.currentTeamId,
    this.profilePhotoPath,
    this.roleId,
    this.state,
    this.city,
    this.pincodes,
    this.status,
    this.createdAt,
    this.updatedAt,
    this.tour,
    this.createdBy,
    this.isOrganization,
    this.organizationName,
    this.gstNo,
    this.bankName,
    this.vendorType,
    this.accountNo,
    this.ifscCode,
    this.panCard,
    this.billingAddress,
    this.organizationId,
    this.tenantId,
    this.isTeamLead,
    this.isLap,
    this.isDemo,
    this.employeeType,
    this.aadharNo,
    this.isFontendVendor,
    this.reference,
    this.deviceId,
    this.fcmId,
    this.authToken,
    this.profilePhotoUrl,
  });

  factory UserProfile.fromJson(Map<String, dynamic> json) => UserProfile(
    id: json["id"],
    name: json["name"],
    email: json["email"],
    emailVerifiedAt: json["email_verified_at"],
    mobile: json["mobile"],
    country: json["country"],
    countryCode: json["country_code"],
    currentTeamId: json["current_team_id"],
    profilePhotoPath: json["profile_photo_path"],
    roleId: json["role_id"],
    state: json["state"],
    city: json["city"],
    pincodes: json["pincodes"],
    status: json["status"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    tour: json["tour"],
    createdBy: json["created_by"],
    isOrganization: json["is_organization"],
    organizationName: json["organization_name"],
    gstNo: json["gst_no"],
    bankName: json["bank_name"],
    vendorType: json["vendor_type"],
    accountNo: json["account_no"],
    ifscCode: json["ifsc_code"],
    panCard: json["pan_card"],
    billingAddress: json["billing_address"],
    organizationId: json["organization_id"],
    tenantId: json["tenant_id"],
    isTeamLead: json["is_team_lead"],
    isLap: json["is_lap"],
    isDemo: json["is_demo"],
    employeeType: json["employee_type"],
    aadharNo: json["aadhar_no"],
    isFontendVendor: json["is_fontend_vendor"],
    reference: json["reference"],
    deviceId: json["device_id"],
    fcmId: json["fcm_id"],
    authToken: json["authToken"],
    profilePhotoUrl: json["profile_photo_url"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "email": email,
    "email_verified_at": emailVerifiedAt,
    "mobile": mobile,
    "country": country,
    "country_code": countryCode,
    "current_team_id": currentTeamId,
    "profile_photo_path": profilePhotoPath,
    "role_id": roleId,
    "state": state,
    "city": city,
    "pincodes": pincodes,
    "status": status,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "tour": tour,
    "created_by": createdBy,
    "is_organization": isOrganization,
    "organization_name": organizationName,
    "gst_no": gstNo,
    "bank_name": bankName,
    "vendor_type": vendorType,
    "account_no": accountNo,
    "ifsc_code": ifscCode,
    "pan_card": panCard,
    "billing_address": billingAddress,
    "organization_id": organizationId,
    "tenant_id": tenantId,
    "is_team_lead": isTeamLead,
    "is_lap": isLap,
    "is_demo": isDemo,
    "employee_type": employeeType,
    "aadhar_no": aadharNo,
    "is_fontend_vendor": isFontendVendor,
    "reference": reference,
    "device_id": deviceId,
    "fcm_id": fcmId,
    "authToken": authToken,
    "profile_photo_url": profilePhotoUrl,
  };
}
