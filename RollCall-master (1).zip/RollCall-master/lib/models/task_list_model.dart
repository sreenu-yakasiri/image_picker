import 'dart:convert';

TaskListModel taskListFromJson(String str) =>
    TaskListModel.fromJson(json.decode(str));

String taskListToJson(TaskListModel data) => json.encode(data.toJson());

class TaskListModel {
  bool? success;
  List<Data>? data;

  TaskListModel({this.success, this.data});

  TaskListModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data!.add(new Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Data {
  int? id;
  String? name;
  int? taskType;
  int? employeeId;
  String? taskAllocateDate;
  String? taskCompletionDate;
  int? taskStatus;
  String? createdAt;
  String? updatedAt;
  String? description;
  String? addonId;
  String? cartAddonId;
  int? createdBy;
  String? tenantId;
  int? isAutoTask;
  String? taskRejectedDate;
  String? taskRejectedNotes;
  String? taskApprovedDate;
  String? taskApprovedNotes;
  int? isIndividual;
  String? message;
  int? projectId;
  String? projectName;
  String? taskStatusValue;
  String? taskTypeName;
  List<Documents>? documents;
  Customers? customers;
  Projects? projects;
  Taskstatus? taskstatus;

  Data(
      {this.id,
      this.name,
      this.taskType,
      this.employeeId,
      this.taskAllocateDate,
      this.taskCompletionDate,
      this.taskStatus,
      this.createdAt,
      this.updatedAt,
      this.description,
      this.addonId,
      this.cartAddonId,
      this.createdBy,
      this.tenantId,
      this.isAutoTask,
      this.taskRejectedDate,
      this.taskRejectedNotes,
      this.taskApprovedDate,
      this.taskApprovedNotes,
      this.isIndividual,
      this.message,
      this.projectId,
      this.projectName,
      this.taskStatusValue,
      this.taskTypeName,
      this.documents,
      this.customers,
      this.projects,
      this.taskstatus});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    taskType = json['task_type'];
    employeeId = json['employee_id'];
    taskAllocateDate = json['task_allocate_date'];
    taskCompletionDate = json['task_completion_date'];
    taskStatus = json['task_status'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    description = json['description'];
    addonId = json['addon_id'];
    cartAddonId = json['cart_addon_id'];
    createdBy = json['created_by'];
    tenantId = json['tenant_id'];
    isAutoTask = json['is_auto_task'];
    taskRejectedDate = json['task_rejected_date'];
    taskRejectedNotes = json['task_rejected_notes'];
    taskApprovedDate = json['task_approved_date'];
    taskApprovedNotes = json['task_approved_notes'];
    isIndividual = json['is_individual'];
    message = json['message'];
    projectId = json['project_id'];
    projectName = json['project_name'];
    taskStatusValue = json['task_status_value'];
    taskTypeName = json['task_type_name'];
    if (json['documents'] != null) {
      documents = <Documents>[];
      json['documents'].forEach((v) {
        documents!.add(new Documents.fromJson(v));
      });
    }
    customers = json['customers'] != null
        ? new Customers.fromJson(json['customers'])
        : null;
    projects = json['projects'] != null
        ? new Projects.fromJson(json['projects'])
        : null;
    taskstatus = json['taskstatus'] != null
        ? new Taskstatus.fromJson(json['taskstatus'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['task_type'] = this.taskType;
    data['employee_id'] = this.employeeId;
    data['task_allocate_date'] = this.taskAllocateDate;
    data['task_completion_date'] = this.taskCompletionDate;
    data['task_status'] = this.taskStatus;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['description'] = this.description;
    data['addon_id'] = this.addonId;
    data['cart_addon_id'] = this.cartAddonId;
    data['created_by'] = this.createdBy;
    data['tenant_id'] = this.tenantId;
    data['is_auto_task'] = this.isAutoTask;
    data['task_rejected_date'] = this.taskRejectedDate;
    data['task_rejected_notes'] = this.taskRejectedNotes;
    data['task_approved_date'] = this.taskApprovedDate;
    data['task_approved_notes'] = this.taskApprovedNotes;
    data['is_individual'] = this.isIndividual;
    data['message'] = this.message;
    data['project_id'] = this.projectId;
    data['project_name'] = this.projectName;
    data['task_status_value'] = this.taskStatusValue;
    data['task_type_name'] = this.taskTypeName;
    if (this.documents != null) {
      data['documents'] = this.documents!.map((v) => v.toJson()).toList();
    }
    if (this.customers != null) {
      data['customers'] = this.customers!.toJson();
    }
    if (this.projects != null) {
      data['projects'] = this.projects!.toJson();
    }
    if (this.taskstatus != null) {
      data['taskstatus'] = this.taskstatus!.toJson();
    }
    return data;
  }
}

class Documents {
  String? message;
  String? path;
  int? id;

  Documents({this.message, this.path, this.id});

  Documents.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    path = json['path'];
    id = json['id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['message'] = this.message;
    data['path'] = this.path;
    data['id'] = this.id;
    return data;
  }
}

class Customers {
  int? id;
  String? name;
  String? email;
  String? emailVerifiedAt;
  String? mobile;
  String? country;
  String? countryCode;
  String? currentTeamId;
  String? profilePhotoPath;
  int? roleId;
  String? state;
  String? city;
  String? pincodes;
  int? status;
  String? createdAt;
  String? updatedAt;
  int? tour;
  int? createdBy;
  int? isOrganization;
  String? organizationName;
  String? gstNo;
  String? bankName;
  String? vendorType;
  String? accountNo;
  String? ifscCode;
  String? panCard;
  String? billingAddress;
  int? organizationId;
  String? tenantId;
  int? isTeamLead;
  int? isLap;
  int? isDemo;
  int? employeeType;
  String? aadharNo;
  int? isFontendVendor;
  String? reference;
  String? deviceId;
  String? fcmId;
  String? bloodGroup;
  String? emergencyNumber;
  String? profilePhotoUrl;

  Customers(
      {this.id,
      this.name,
      this.email,
      this.emailVerifiedAt,
      this.mobile,
      this.country,
      this.countryCode,
      this.currentTeamId,
      this.profilePhotoPath,
      this.roleId,
      this.state,
      this.city,
      this.pincodes,
      this.status,
      this.createdAt,
      this.updatedAt,
      this.tour,
      this.createdBy,
      this.isOrganization,
      this.organizationName,
      this.gstNo,
      this.bankName,
      this.vendorType,
      this.accountNo,
      this.ifscCode,
      this.panCard,
      this.billingAddress,
      this.organizationId,
      this.tenantId,
      this.isTeamLead,
      this.isLap,
      this.isDemo,
      this.employeeType,
      this.aadharNo,
      this.isFontendVendor,
      this.reference,
      this.deviceId,
      this.fcmId,
      this.bloodGroup,
      this.emergencyNumber,
      this.profilePhotoUrl});

  Customers.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    email = json['email'];
    emailVerifiedAt = json['email_verified_at'];
    mobile = json['mobile'];
    country = json['country'];
    countryCode = json['country_code'];
    currentTeamId = json['current_team_id'];
    profilePhotoPath = json['profile_photo_path'];
    roleId = json['role_id'];
    state = json['state'];
    city = json['city'];
    pincodes = json['pincodes'];
    status = json['status'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    tour = json['tour'];
    createdBy = json['created_by'];
    isOrganization = json['is_organization'];
    organizationName = json['organization_name'];
    gstNo = json['gst_no'];
    bankName = json['bank_name'];
    vendorType = json['vendor_type'];
    accountNo = json['account_no'];
    ifscCode = json['ifsc_code'];
    panCard = json['pan_card'];
    billingAddress = json['billing_address'];
    organizationId = json['organization_id'];
    tenantId = json['tenant_id'];
    isTeamLead = json['is_team_lead'];
    isLap = json['is_lap'];
    isDemo = json['is_demo'];
    employeeType = json['employee_type'];
    aadharNo = json['aadhar_no'];
    isFontendVendor = json['is_fontend_vendor'];
    reference = json['reference'];
    deviceId = json['device_id'];
    fcmId = json['fcm_id'];
    bloodGroup = json['blood_group'];
    emergencyNumber = json['emergency_number'];
    profilePhotoUrl = json['profile_photo_url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['email'] = this.email;
    data['email_verified_at'] = this.emailVerifiedAt;
    data['mobile'] = this.mobile;
    data['country'] = this.country;
    data['country_code'] = this.countryCode;
    data['current_team_id'] = this.currentTeamId;
    data['profile_photo_path'] = this.profilePhotoPath;
    data['role_id'] = this.roleId;
    data['state'] = this.state;
    data['city'] = this.city;
    data['pincodes'] = this.pincodes;
    data['status'] = this.status;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['tour'] = this.tour;
    data['created_by'] = this.createdBy;
    data['is_organization'] = this.isOrganization;
    data['organization_name'] = this.organizationName;
    data['gst_no'] = this.gstNo;
    data['bank_name'] = this.bankName;
    data['vendor_type'] = this.vendorType;
    data['account_no'] = this.accountNo;
    data['ifsc_code'] = this.ifscCode;
    data['pan_card'] = this.panCard;
    data['billing_address'] = this.billingAddress;
    data['organization_id'] = this.organizationId;
    data['tenant_id'] = this.tenantId;
    data['is_team_lead'] = this.isTeamLead;
    data['is_lap'] = this.isLap;
    data['is_demo'] = this.isDemo;
    data['employee_type'] = this.employeeType;
    data['aadhar_no'] = this.aadharNo;
    data['is_fontend_vendor'] = this.isFontendVendor;
    data['reference'] = this.reference;
    data['device_id'] = this.deviceId;
    data['fcm_id'] = this.fcmId;
    data['blood_group'] = this.bloodGroup;
    data['emergency_number'] = this.emergencyNumber;
    data['profile_photo_url'] = this.profilePhotoUrl;
    return data;
  }
}

class Projects {
  int? id;
  String? name;
  int? status;
  String? createdAt;
  String? updatedAt;
  int? createdBy;
  String? tenantId;
  String? startDate;
  String? endDate;

  Projects(
      {this.id,
      this.name,
      this.status,
      this.createdAt,
      this.updatedAt,
      this.createdBy,
      this.tenantId,
      this.startDate,
      this.endDate});

  Projects.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    status = json['status'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    createdBy = json['created_by'];
    tenantId = json['tenant_id'];
    startDate = json['start_date'];
    endDate = json['end_date'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['status'] = this.status;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['created_by'] = this.createdBy;
    data['tenant_id'] = this.tenantId;
    data['start_date'] = this.startDate;
    data['end_date'] = this.endDate;
    return data;
  }
}

class Taskstatus {
  int? id;
  String? name;
  String? createdAt;
  String? updatedAt;
  int? status;
  int? order;

  Taskstatus(
      {this.id,
      this.name,
      this.createdAt,
      this.updatedAt,
      this.status,
      this.order});

  Taskstatus.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    status = json['status'];
    order = json['order'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['status'] = this.status;
    data['order'] = this.order;
    return data;
  }
}
