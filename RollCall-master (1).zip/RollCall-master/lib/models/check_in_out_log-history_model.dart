// To parse this JSON data, do
//
//     final checkInOutLogHistoryModel = checkInOutLogHistoryModelFromJson(jsonString);

import 'dart:convert';

CheckInOutLogHistoryModel checkInOutLogHistoryModelFromJson(String str) => CheckInOutLogHistoryModel.fromJson(json.decode(str));

String checkInOutLogHistoryModelToJson(CheckInOutLogHistoryModel data) => json.encode(data.toJson());

class CheckInOutLogHistoryModel {
  final bool success;
  final String message;
  final List<AttendanceList> attendanceList;

  CheckInOutLogHistoryModel({
    required this.success,
    required this.message,
    required this.attendanceList,
  });

  factory CheckInOutLogHistoryModel.fromJson(Map<String, dynamic> json) => CheckInOutLogHistoryModel(
    success: json["success"],
    message: json["message"],
    attendanceList: List<AttendanceList>.from(json["attendanceList"].map((x) => AttendanceList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "message": message,
    "attendanceList": List<dynamic>.from(attendanceList.map((x) => x.toJson())),
  };
}

class AttendanceList {
  final int id;
  final int userId;
  final String type;
  final String latitude;
  final String longitude;
  final int status;
  final DateTime createdAt;
  final DateTime updatedAt;
  final String year;
  final DateTime logDateTime;
  final String subType;
  final DateTime recordDate;
  final String? subtypeName;

  AttendanceList({
    required this.id,
    required this.userId,
    required this.type,
    required this.latitude,
    required this.longitude,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
    required this.year,
    required this.logDateTime,
    required this.subType,
    required this.recordDate,
    this.subtypeName,
  });

  factory AttendanceList.fromJson(Map<String, dynamic> json) => AttendanceList(
    id: json["id"],
    userId: json["user_id"],
    type: json["type"],
    latitude: json["latitude"],
    longitude: json["longitude"],
    status: json["status"],
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
    year: json["year"],
    logDateTime: DateTime.parse(json["log_date_time"]),
    subType: json["sub_type"],
    recordDate: DateTime.parse(json["record_date"]),
    subtypeName: json["subtype_name"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "user_id": userId,
    "type": type,
    "latitude": latitude,
    "longitude": longitude,
    "status": status,
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
    "year": year,
    "log_date_time": logDateTime.toIso8601String(),
    "sub_type": subType,
    "record_date": "${recordDate.year.toString().padLeft(4, '0')}-${recordDate.month.toString().padLeft(2, '0')}-${recordDate.day.toString().padLeft(2, '0')}",
    "subtype_name": subtypeName,
  };
}
