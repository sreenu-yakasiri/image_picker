// To parse this JSON data, do
//
//     final availableLeavesModel = availableLeavesModelFromJson(jsonString);

import 'dart:convert';

AvailableLeavesModel availableLeavesModelFromJson(String str) => AvailableLeavesModel.fromJson(json.decode(str));

String availableLeavesModelToJson(AvailableLeavesModel data) => json.encode(data.toJson());

class AvailableLeavesModel {
  bool success;
  List<AvailableLeaveList> availableLeaveList;

  AvailableLeavesModel({
    required this.success,
    required this.availableLeaveList,
  });

  factory AvailableLeavesModel.fromJson(Map<String, dynamic> json) => AvailableLeavesModel(
    success: json["success"],
    availableLeaveList: List<AvailableLeaveList>.from(json["availableLeaveList"].map((x) => AvailableLeaveList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "availableLeaveList": List<dynamic>.from(availableLeaveList.map((x) => x.toJson())),
  };
}

class AvailableLeaveList {
  String leave;
  int count;

  AvailableLeaveList({
    required this.leave,
    required this.count,
  });

  factory AvailableLeaveList.fromJson(Map<String, dynamic> json) => AvailableLeaveList(
    leave: json["leave"],
    count: json["count"],
  );

  Map<String, dynamic> toJson() => {
    "leave": leave,
    "count": count,
  };
}
