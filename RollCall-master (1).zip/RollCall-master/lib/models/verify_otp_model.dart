import 'dart:convert';
import 'package:employee_attendance/models/user_profile.dart';

VerifyOtpModel verifyOtpModelFromJson(String str) =>
    VerifyOtpModel.fromJson(json.decode(str));

String verifyOtpModelToJson(VerifyOtpModel data) => json.encode(data.toJson());

class VerifyOtpModel {
  final bool success;
  final String? message;
  final UserProfile? profile;

  VerifyOtpModel({
    required this.success,
    this.message,
    this.profile,
  });

  factory VerifyOtpModel.fromJson(Map<String, dynamic> json) => VerifyOtpModel(
        success: json["success"],
        message: json["message"],
        profile: json["profile"] == null
            ? null
            : UserProfile.fromJson(json["profile"]),
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "message": message,
        "profile": profile?.toJson(),
      };
}
