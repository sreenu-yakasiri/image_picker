import 'dart:convert';

AppliedLeavesModel appliedLeaveFromJson(String str) =>
    AppliedLeavesModel.fromJson(json.decode(str));

String appliedLeaveToJson(AppliedLeavesModel data) =>
    json.encode(data.toJson());

class AppliedLeavesModel {
  bool? success;
  List<LeaveData>? leaveData;

  AppliedLeavesModel({this.success, this.leaveData});

  AppliedLeavesModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    if (json['leaveData'] != null) {
      leaveData = <LeaveData>[];
      json['leaveData'].forEach((v) {
        leaveData!.add(new LeaveData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    if (this.leaveData != null) {
      data['leaveData'] = this.leaveData!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class LeaveData {
  int? id;
  int? userId;
  int? status;
  String? appliedDate;
  LeaveType? leaveType;
  String? createdAt;
  String? updatedAt;
  String? year;
  Null? note;
  String? toDate;
  String? fromDate;
  int? noOfDay;
  String? leaveStatus;
  String? leaveTypeName;

  LeaveData(
      {this.id,
      this.userId,
      this.status,
      this.appliedDate,
      this.leaveType,
      this.createdAt,
      this.updatedAt,
      this.year,
      this.note,
      this.toDate,
      this.fromDate,
      this.noOfDay,
      this.leaveStatus,
      this.leaveTypeName});

  LeaveData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    status = json['status'];
    appliedDate = json['applied_date'];
    leaveType = json['leave_type'] != null
        ? new LeaveType.fromJson(json['leave_type'])
        : null;
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    year = json['year'];
    note = json['note'];
    toDate = json['to_date'];
    fromDate = json['from_date'];
    noOfDay = json['no_of_day'];
    leaveStatus = json['leave_status'];
    leaveTypeName = json['leave_type_name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['status'] = this.status;
    data['applied_date'] = this.appliedDate;
    if (this.leaveType != null) {
      data['leave_type'] = this.leaveType!.toJson();
    }
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['year'] = this.year;
    data['note'] = this.note;
    data['to_date'] = this.toDate;
    data['from_date'] = this.fromDate;
    data['no_of_day'] = this.noOfDay;
    data['leave_status'] = this.leaveStatus;
    data['leave_type_name'] = this.leaveTypeName;
    return data;
  }
}

class LeaveType {
  int? id;
  String? name;
  int? status;
  String? createdAt;
  String? updatedAt;

  LeaveType({this.id, this.name, this.status, this.createdAt, this.updatedAt});

  LeaveType.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    status = json['status'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['status'] = this.status;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
