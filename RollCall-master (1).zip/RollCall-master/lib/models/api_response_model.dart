import 'dart:convert';

ApiResponseModel apiResponseFromJson(String str) =>
    ApiResponseModel.fromJson(json.decode(str));

String apiResponseToJson(ApiResponseModel data) => json.encode(data.toJson());

class ApiResponseModel {
  ApiResponseModel({
    required this.success,
    required this.message,
  });
  late final bool success;
  late final String message;

  ApiResponseModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['success'] = success;
    _data['message'] = message;
    return _data;
  }
}
