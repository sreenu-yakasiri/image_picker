import 'package:image_picker/image_picker.dart';

class ImageModel {
  XFile? localImage;
  String? content;

    ImageModel(XFile? localImage, String? content){
      this.localImage = localImage;
      this.content = content;
    }
}