// To parse this JSON data, do
//
//     final holidaysListModel = holidaysListModelFromJson(jsonString);

import 'dart:convert';

HolidaysListModel holidaysListModelFromJson(String str) => HolidaysListModel.fromJson(json.decode(str));

String holidaysListModelToJson(HolidaysListModel data) => json.encode(data.toJson());
class HolidaysListModel {
  HolidaysListModel({
    required this.success,
    required this.holidatList,
  });
  late final bool success;
  late final List<HolidatList> holidatList;

  HolidaysListModel.fromJson(Map<String, dynamic> json){
    success = json['success'];
    holidatList = List.from(json['holidatList']).map((e)=>HolidatList.fromJson(e)).toList();
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['success'] = success;
    _data['holidatList'] = holidatList.map((e)=>e.toJson()).toList();
    return _data;
  }
}

class HolidatList {
  HolidatList({
    required this.id,
    required this.name,
    required this.date,
    required this.createdAt,
    this.updatedAt,
    required this.status,
    this.description,
    required this.tenantId,
    required this.createdBy,
  });
  late final int id;
  late final String name;
  late final String date;
  late final String createdAt;
  late final String? updatedAt;
  late final int status;
  late final String? description;
  late final String tenantId;
  late final int createdBy;

  HolidatList.fromJson(Map<String, dynamic> json){
    id = json['id'];
    name = json['name'];
    date = json['date'];
    createdAt = json['created_at'];
    updatedAt = null;
    status = json['status'];
    description = null;
    tenantId = json['tenant_id'];
    createdBy = json['created_by'];
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['id'] = id;
    _data['name'] = name;
    _data['date'] = date;
    _data['created_at'] = createdAt;
    _data['updated_at'] = updatedAt;
    _data['status'] = status;
    _data['description'] = description;
    _data['tenant_id'] = tenantId;
    _data['created_by'] = createdBy;
    return _data;
  }
}