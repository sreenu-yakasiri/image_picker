import 'dart:convert';

CheckInOutModel checkInOutModelFromJson(String str) =>
    CheckInOutModel.fromJson(json.decode(str));

String checkInOutModelToJson(CheckInOutModel data) =>
    json.encode(data.toJson());

class CheckInOutModel {
  bool success = false;
  String? message;
  AttendanceList? attendanceList;

  CheckInOutModel({required this.success, this.message, this.attendanceList});

  CheckInOutModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    message = json['message'];
    attendanceList = json['attendanceList'] != null
        ? AttendanceList?.fromJson(json['attendanceList'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['success'] = success;
    data['message'] = message;
    data['attendanceList'] = attendanceList!.toJson();
    return data;
  }
}

class AttendanceList {
  String? userid;
  String? type;
  String? subtype;
  String? latitude;
  String? longitude;
  String? logdatetime;
  String? recorddate;
  String? year;
  String? batterystatus;
  String? deviceid;
  String? deviceinfo;
  String? updatedat;
  String? createdat;
  int? id;
  int? ischeckin;

  AttendanceList(
      {this.userid,
      this.type,
      this.subtype,
      this.latitude,
      this.longitude,
      this.logdatetime,
      this.recorddate,
      this.year,
      this.batterystatus,
      this.deviceid,
      this.deviceinfo,
      this.updatedat,
      this.createdat,
      this.id,
      this.ischeckin});

  AttendanceList.fromJson(Map<String, dynamic> json) {
    userid = json['user_id'];
    type = json['type'];
    subtype = json['sub_type'];
    latitude = json['latitude'];
    longitude = json['longitude'];
    logdatetime = json['log_date_time'];
    recorddate = json['record_date'];
    year = json['year'];
    batterystatus = json['battery_status'];
    deviceid = json['device_id'];
    deviceinfo = json['device_info'];
    updatedat = json['updated_at'];
    createdat = json['created_at'];
    id = json['id'];
    ischeckin = json['is_check_in'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['user_id'] = userid;
    data['type'] = type;
    data['sub_type'] = subtype;
    data['latitude'] = latitude;
    data['longitude'] = longitude;
    data['log_date_time'] = logdatetime;
    data['record_date'] = recorddate;
    data['year'] = year;
    data['battery_status'] = batterystatus;
    data['device_id'] = deviceid;
    data['device_info'] = deviceinfo;
    data['updated_at'] = updatedat;
    data['created_at'] = createdat;
    data['id'] = id;
    data['is_check_in'] = ischeckin;
    return data;
  }
}
