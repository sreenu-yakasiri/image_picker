// To parse this JSON data, do
//
//     final otpModel = otpModelFromJson(jsonString);

import 'dart:convert';

OtpModel otpModelFromJson(String str) => OtpModel.fromJson(json.decode(str));

String otpModelToJson(OtpModel data) => json.encode(data.toJson());

class OtpModel {
  bool success;
  final int? otp;
  final String message;

  OtpModel({
    required this.success,
    this.otp,
    required this.message,
  });

  factory OtpModel.fromJson(Map<String, dynamic> json) => OtpModel(
    success: json["success"],
    otp: json["otp"],
    message: json["message"],
  );

  Map<String, dynamic> toJson() => {
    "mobile": success,
    "otp": otp,
    "message": message,
  };
}
