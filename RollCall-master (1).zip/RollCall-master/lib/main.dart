import 'package:employee_attendance/providers/BottomNavigationBarProvider.dart';
import 'package:employee_attendance/providers/DataProvider.dart';
import 'package:employee_attendance/providers/apply_leave_provider.dart';
import 'package:employee_attendance/providers/banners_provider.dart';
import 'package:employee_attendance/providers/check_in_out_log_provider.dart';
import 'package:employee_attendance/providers/check_in_out_provider.dart';
import 'package:employee_attendance/providers/send_otp_provider.dart';
import 'package:employee_attendance/providers/task_details_provider.dart';
import 'package:employee_attendance/providers/user_provider.dart';
import 'package:employee_attendance/providers/verify_otp_provider.dart';
import 'package:employee_attendance/ui/screens/check_in_out/check_in_out_page.dart';
import 'package:employee_attendance/ui/screens/holiday_list_page.dart';
import 'package:employee_attendance/ui/screens/home/home_page.dart';
import 'package:employee_attendance/ui/screens/leave/applied_leaves_page.dart';
import 'package:employee_attendance/ui/screens/leave/apply_leave_page.dart';
import 'package:employee_attendance/ui/screens/leave/available_leaves_page.dart';
import 'package:employee_attendance/ui/screens/login/login_page.dart';
import 'package:employee_attendance/ui/screens/login/otp_page.dart';
import 'package:employee_attendance/ui/screens/mytasks/my_tasks_page.dart';
import 'package:employee_attendance/ui/screens/mytasks/task_details_page.dart';
import 'package:employee_attendance/ui/screens/profile_page.dart';
import 'package:employee_attendance/ui/screens/welcome_page.dart';
import 'package:employee_attendance/utils/app_url.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'firebase_options.dart';

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
}

GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey =
    GlobalKey<ScaffoldMessengerState>();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => SendOTPProvider()),
        ChangeNotifierProvider(create: (_) => VerifyOTPProvider()),
        ChangeNotifierProvider(create: (_) => UserProvider()),
        ChangeNotifierProvider(create: (_) => DataProvider()),
        ChangeNotifierProvider(create: (_) => CheckInOutLogProvider()),
        ChangeNotifierProvider(create: (_) => CheckInOutProvider()),
        ChangeNotifierProvider(create: (_) => BannersProvider()),
        ChangeNotifierProvider(create: (_) => ApplyLeaveProvider()),
        ChangeNotifierProvider(create: (_) => BottomNavigationBarProvider()),
      ],
      child: MaterialApp(
        routes: {
          '/': (context) => const WelcomePage(), //Home(),
          '/login_page': (context) => const LoginPage(),
          '/otp_page': (context) => const VerifyOTPPage(),
          '/home_page': (context) => const HomePage(),
          '/profile_page': (context) => const MyProfile(),
          '/applied_leaves': (context) => const AppliedLeavesPage(),
          '/apply_leave': (context) => const ApplyLeavePage(),
          '/holiday_list': (context) => const HolidayListPage(),
          '/available_leaves': (context) => const AvailableLeavesPage(),
          '/check_in_out_page': (context) => const CheckInOutPage(),
          '/my_tasks_page': (context) => const MyTasksPage(),
          '/task_detail': (context) =>
              ChangeNotifierProvider<TaskDetailsProvider>(
                create: (_) => TaskDetailsProvider(),
                child: TaskDetailsPage(),
              ),
        },
        title: AppUrl.appName,
        scaffoldMessengerKey: scaffoldMessengerKey,
        theme: ThemeData(
          //primarySwatch: Colors.pinkAccent,
          primaryColor: Colors.pinkAccent,
          appBarTheme: AppBarTheme(
            backgroundColor: Colors.pinkAccent,
          ),
          colorScheme: ColorScheme.fromSeed(
            seedColor: Colors.white,
            // ···
            //brightness: Brightness.dark,
          ),
          // This is the theme of your application.
          //colorScheme: ColorScheme.fromSeed(seedColor: Colors.white70),
          scaffoldBackgroundColor: Colors.white,
          useMaterial3: true,
        ),
      ),
    );
  }
}
