package com.example.employee_attendance;

import static android.content.Context.BATTERY_SERVICE;

import android.content.Context;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;

import androidx.annotation.Nullable;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.crashlytics.FirebaseCrashlytics;

import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

public class ApiHelper {

    public static String getDeviceInfo()
    {
        return "BRAND : "+Build.BRAND
                +"\nDISPLAY : "+Build.DISPLAY
                +"\nFINGERPRINT : "+Build.FINGERPRINT
                +"\nHARDWARE : "+Build.HARDWARE
                +"\nHOST : "+Build.HOST
                +"\nMANUFACTURER : "+Build.MANUFACTURER
                +"\nMODEL : "+Build.MODEL
                +"\nPRODUCT : "+Build.PRODUCT
                +"\nSERIAL : "+Build.SERIAL
                +"\nTYPE : "+Build.TYPE
                +"\nUNKNOWN : "+Build.UNKNOWN
                +"\nUSER : "+Build.USER;
    }

    public static String getBatteryLevel(Context context)
    {
        // Call battery manager service
        BatteryManager bm = (BatteryManager)context.getSystemService(BATTERY_SERVICE);
        // Get the battery percentage and store it in a INT variable
        int level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);

        return Integer.toString(level);
    }
    public static void locationApi(Context context,String userId, String lat, String lang){

        RequestQueue queue = Volley.newRequestQueue(context);
        String url = "https://rollcall.varthmaan.com/api/location_tracking?user_id="
                +userId+"&track_lng="+lang+"&track_lat="+lat;
        FirebaseCrashlytics.getInstance().log("api location request :"+url);
        Log.d("RC","Loc url "+url.toString());

        Bundle params = new Bundle();
        params.putString("LocationApiURL", url);
        FirebaseAnalytics.getInstance(context).logEvent("Location", params);
        StringRequest request = new StringRequest(Request.Method.POST,
                url,
                new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Bundle params = new Bundle();
                params.putString("LocationResponse", response);
                params.putString("userId", userId);
                FirebaseAnalytics.getInstance(context).logEvent("Location", params);

                Log.d("RC","Loc onResponse "+response.toString());
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                FirebaseCrashlytics.getInstance().recordException(error);
                Bundle params = new Bundle();
                params.putString("LocationResponseError", error.toString());
                params.putString("userId", userId);
                FirebaseAnalytics.getInstance(context).logEvent("Location", params);

                Log.d("RC","Loc onErrorResponse "+ error.toString());
            }
        }) {
            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };

        queue.add(request);
    }

    public static void battertApi(Context context,String userId){
        String deviceId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        String url ="https://rollcall.varthmaan.com/api/battery/status?" +
                "user_id="+userId+
                "&status="+getBatteryLevel(context)+
                "&device_id="+deviceId+
                "&device_info="+getDeviceInfo();

        RequestQueue queue = Volley.newRequestQueue(context);
        StringRequest request = new StringRequest(Request.Method.POST,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("RC","onResponse battery "+response.toString());
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("RC","onErrorResponse battery "+ error.toString());
            }
        }) {
            @Override
            public String getBodyContentType() {
                return "application/json";
            }
        };

        queue.add(request);
    }
}
