package com.example.employee_attendance

import android.content.Context
import android.location.Location
//import android.location.LocationRequest
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
//import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

class LocationHelper {
    private val WAIT_TIME = 10000L //5 mins

    private val UPDATE_INTERVAL_IN_MILLISECONDS = 15000L // 5 mins

    private val FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS = 10000L //3 mins

    private var mLocationRequest: LocationRequest? = null
    private var mFusedLocationClient: FusedLocationProviderClient? = null
    private var mLocationCallback: LocationCallback? = null
    private val TAG = "LOCATION_TRACKING"
    private var myLocationListener: MyLocationListener? = null

   public fun init (context: Context?) {
        mLocationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                super.onLocationResult(locationResult)
                if (myLocationListener != null) {
                    myLocationListener!!.onLocationChanged(locationResult.lastLocation)
                }
            }
        }
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(context!!)
        createLocationRequest()
        //stopLocationUpdates()

        Handler(Looper.getMainLooper()).postDelayed({ requestLocationUpdates() }, 1500)
    }

    fun startListeningUserLocation(myLocationListener: MyLocationListener?) {
        this.myLocationListener = myLocationListener
    }

    private fun requestLocationUpdates() {
        Log.i(TAG, "Requesting location updates")
        try {
            mFusedLocationClient!!.requestLocationUpdates(
                mLocationRequest!!,
                mLocationCallback!!, Looper.myLooper()
            )
        } catch (unlikely: SecurityException) {
            Log.e(TAG, "Lost location permission. Could not request updates. $unlikely")
        }
    }

    fun stopLocationUpdates() {
        try {
            Log.d(TAG, "Location Updates Stopped")
            myLocationListener = null
            mFusedLocationClient!!.removeLocationUpdates(mLocationCallback!!)
        } catch (e: Exception) {
            Log.d(TAG, e.message!!)
        }
    }

    private fun createLocationRequest() {
        mLocationRequest = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY,
            MyApplication.locationIntervalTimeout.toLong()
        )
            .setWaitForAccurateLocation(true)
            .setMinUpdateIntervalMillis(MyApplication.locationIntervalTimeout.toLong())
            .setMaxUpdateDelayMillis(MyApplication.locationIntervalTimeout.toLong())
            .build()
    }


    interface MyLocationListener {
        fun onLocationChanged(location: Location?)
    }
}