package com.example.employee_attendance

import android.Manifest
import android.app.ActivityManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugins.GeneratedPluginRegistrant

class MainActivity: FlutterFragmentActivity() {
    private var permission: ArrayList<String> = ArrayList()
    private var isLocG = false
    private var isLocGB = false


    override fun onCreate(
        savedInstanceState: android.os.Bundle?,
        persistentState: android.os.PersistableBundle?
    ) {
        super.onCreate(savedInstanceState, persistentState)

    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        GeneratedPluginRegistrant.registerWith(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "nativeChannel")
            .setMethodCallHandler { call: MethodCall, result ->

                when (call.method) {
                    "method" -> {
                        val intent = Intent(
                            this,
                            PermissionActivity::class.java
                        )
                        MyApplication.userId = call.arguments.toString();
                        android.util.Log.d("RC" , "userid is "+MyApplication.userId )
                        intent.putExtra("userId", MyApplication.userId )
                        startActivity(intent)
                        //result.success(true)
                    }
                    "checkPermissions"->{
                        MyApplication.userId = call.arguments.toString();
                         var gpsEnabled = PermissionActivity.gpsEnabled(this)
                        var permissionResult = PermissionActivity.checkIfAllPermissionsGranted(this)

                        if(!(permissionResult && gpsEnabled))
                        {
                            //stop service if permissions are disabled.
                            ServiceHelper().stopLocationService(applicationContext)
                        }
                        result.success(permissionResult && gpsEnabled)
                    }
                    "startLocationService"->{
                        MyApplication.userId = call.argument("userID")
                        MyApplication.setLocationInterval(call.argument("locationTimeInterval"));
                        android.util.Log.d("RC" , "userid is "+MyApplication.userId + "interval : "+MyApplication.locationIntervalTimeout)

                        var gpsEnabled = PermissionActivity.gpsEnabled(this)
                        var permissionResult = PermissionActivity.checkIfAllPermissionsGranted(this)
                        if(permissionResult && gpsEnabled)
                        {
                            ServiceHelper().startLocationService(applicationContext)
                        }
                        else
                        {
                            ServiceHelper().stopLocationService(applicationContext)
                        }
                        result.success(permissionResult && gpsEnabled)
                    }

                    "batteryInfo"->{
                        result.success(ApiHelper.getBatteryLevel(this))
                    }

                    "deviceInfo"->{
                        result.success(ApiHelper.getDeviceInfo())
                    }

                }

            }
    }
}
