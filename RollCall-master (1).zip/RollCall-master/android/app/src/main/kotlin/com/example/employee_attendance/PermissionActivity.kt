package com.example.employee_attendance

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class PermissionActivity : AppCompatActivity() {
    private var permission: ArrayList<String> = ArrayList()
    private var isLocG = false
    private var isLocGB = false
    private lateinit var serviceHelper: ServiceHelper;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_permission)
        serviceHelper = ServiceHelper();
        var btn = findViewById<Button>(R.id.permission_btn);
        btn.setOnClickListener {
            try{
                if(gpsEnabled(applicationContext))
                {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        if (isLocG && isLocGB && isNotificationEnabled()) {
                            serviceHelper.startLocationService(applicationContext)
                        } else {
                            if (!isLocG) {
                                permission.add(Manifest.permission.ACCESS_FINE_LOCATION)
                                permission.add(Manifest.permission.ACCESS_COARSE_LOCATION)
                            } else {
                                permission.add(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                            }
                            permission.add(Manifest.permission.POST_NOTIFICATIONS)

                            checkPermission()
                        }
                    } else {
                        if (isLocG) {
                            serviceHelper.startLocationService(applicationContext)
                        } else {
                            permission.add(Manifest.permission.ACCESS_FINE_LOCATION)
                            permission.add(Manifest.permission.ACCESS_COARSE_LOCATION)
                            checkPermission()
                        }
                    }
                }
                else
                {
                    showAlertDialogPermission(
                        this,
                        "Please enable GPS to track the location.", false
                    )
                    {
                    }
                }

                //setText(myText)
            } catch (e: Exception){
                var ss= e.toString()
                var qss= e.toString()
            }
        }

    }

    private  fun isNotificationEnabled(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    }
    private fun requestPermissions() {
        val permissions = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.POST_NOTIFICATIONS,
        )
        ActivityCompat.requestPermissions(this, permissions, 111)
    }

    private fun requestBackgroundLocationPermissions() {
        val permissions = arrayOf(
            Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        ActivityCompat.requestPermissions(this, permissions, 111)
    }

    private fun requestNotificationPermissions() {
        val permissions = arrayOf(
            Manifest.permission.POST_NOTIFICATIONS)
        ActivityCompat.requestPermissions(this, permissions, 111)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode === 111) {
            // Check if all permissions are granted
            for ((i, item) in permissions.withIndex()) {
                if(item.equals(Manifest.permission.ACCESS_COARSE_LOCATION)||
                    item.equals(Manifest.permission.ACCESS_COARSE_LOCATION))
                {
                    if(grantResults[i] == PackageManager.PERMISSION_GRANTED)
                    {
                        isLocG = true;
                    }
                }
                else if(item.equals(Manifest.permission.ACCESS_BACKGROUND_LOCATION))
                {
                    if(grantResults[i] == PackageManager.PERMISSION_GRANTED)
                    {
                        isLocGB = true;
                    }
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                if(!isLocGB)
                {
                    showAlertDialogPermission(this,
                        "To accurately track the location while the App is running on screen or is minimised , App needs to use your Location. Set it to ALLOW ALL THE TIME",
                        true) {
                        requestBackgroundLocationPermissions()
                    }
                    return
                }
                if(ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) != PackageManager.PERMISSION_GRANTED)
                {
                    showAlertDialogPermission(this,
                        "Notifcations permissions are required to keep you informed.",
                        true,) {
                        navigateToSettings()
                    }
                    return
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                if (isLocG && isLocGB) {
                    serviceHelper.startLocationService(applicationContext)
                }
            } else {
                if (isLocG) {
                    serviceHelper.startLocationService(applicationContext)
                }
            }
        }
    }



    companion object{

        public fun gpsEnabled(context: Context) : Boolean
        {
            val mLocationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val mGPS = mLocationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)

            return mGPS;
        }
        fun checkIfAllPermissionsGranted(context: Activity): Boolean
        {
            val p1 = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED

            val p2 = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {

                val p3 = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.ACCESS_BACKGROUND_LOCATION
                ) == PackageManager.PERMISSION_GRANTED

                val p4 = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED

                return (p1 or p2) && p3 && p4;
            }

            return (p1 or p2)
        }
    }

    private fun checkPermission() {

        val p1 = ContextCompat.checkSelfPermission(
            applicationContext,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val p2 = ContextCompat.checkSelfPermission(
            applicationContext,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (!(p1 or p2)) {
            permission.add(Manifest.permission.ACCESS_FINE_LOCATION)
            permission.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }

        isLocG = p1 or p2

        if (isLocG) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {

                val p3 = ContextCompat.checkSelfPermission(
                    applicationContext,
                    Manifest.permission.ACCESS_BACKGROUND_LOCATION
                ) == PackageManager.PERMISSION_GRANTED


                if (!p3) {
                    permission.add(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                }

                isLocGB = p3
            }
        }

        val p5 = ContextCompat.checkSelfPermission(
            applicationContext,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED

        if(!p5)
        {
            permission.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (permission.isNotEmpty()) {
            askPermissions()
        }
    }

    private fun askPermissions() {
        requestPermissions()
    }

    @Suppress("DEPRECATION")


    private fun navigateToSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        with(intent) {
            data = Uri.fromParts("package", packageName, null)
            addCategory(Intent.CATEGORY_DEFAULT)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
            addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        }
        startActivity(intent)
    }

    fun showAlertDialogPermission(context: Context, message: String, enableNegativeButton: Boolean, success: () -> Unit) {
        val builder1: AlertDialog.Builder = AlertDialog.Builder(context)
        builder1.setTitle("Alert")
        builder1.setMessage(message)
        builder1.setCancelable(false)
        builder1.setPositiveButton(
            if (enableNegativeButton) "Settings" else "Ok"
        ) { _, _ ->
            success.invoke()
        }

        if(enableNegativeButton)
        {
            builder1.setNegativeButton(
                "Cancel"
            ) { dialog, _ ->
                dialog.cancel()
            }
        }

        val alert11: AlertDialog = builder1.create()
        alert11.show()

    }
}
