package com.example.employee_attendance;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;

import java.util.concurrent.TimeUnit;

public class MyApplication extends Application {
    public static String userId = null;
    public static long locationIntervalTimeout = 540000; //9 minutes in milli

    @Override
    public void onCreate() {
        super.onCreate();
    }

    public static void setLocationInterval(String time)
    {
        try{
            if(time != null)
            {
                //locationIntervalTimeout = TimeUnit.MINUTES.toMillis(Integer.parseInt(time));
                locationIntervalTimeout = 1000;
            }
            // is an integer!
        } catch (Exception e) {
            // not an integer!
            locationIntervalTimeout = TimeUnit.MINUTES.toMillis(9);
        }

    }
}
