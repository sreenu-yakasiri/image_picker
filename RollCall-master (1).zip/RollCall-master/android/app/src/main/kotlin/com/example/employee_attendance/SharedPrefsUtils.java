package com.example.employee_attendance;

import android.content.Context;

public class SharedPrefsUtils {
    private static String SP_DEFAULT_VALUE = "NA";

}
