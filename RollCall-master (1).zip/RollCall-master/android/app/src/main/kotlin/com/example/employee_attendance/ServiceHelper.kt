package com.example.employee_attendance

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity

class ServiceHelper {

    public fun startLocationService(applicationContext: Context, ) {
        if (!isServiceRunning(applicationContext,"com.example.employee_attendance" + LocationService::class.java.simpleName)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                applicationContext.startForegroundService(
                    Intent(
                        applicationContext,
                        LocationService::class.java
                    )
                )
            } else {
                applicationContext.startService(Intent(applicationContext, LocationService::class.java))
            }
        }
        //restart the app after starting the location service.
        val i = Intent(applicationContext,MainActivity::class.java)
        i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
        applicationContext.startActivity(i)
    }

    private fun isServiceRunning(applicationContext:Context, serviceName: String): Boolean {
        var serviceRunning = false
        val am = applicationContext.getSystemService(AppCompatActivity.ACTIVITY_SERVICE) as ActivityManager
        for (runningServiceInfo in am.getRunningServices(Int.MAX_VALUE)) {
            if (runningServiceInfo.service.className.equals(serviceName, ignoreCase = true)) {
                if (runningServiceInfo.foreground) {
                    serviceRunning = true
                }
            }
        }
        return serviceRunning
    }

    public fun stopLocationService(applicationContext:Context) {
        try {
            applicationContext.stopService(Intent(applicationContext, LocationService::class.java))
            //viewModel.saveSpData(LOCATION, "disable")
            //showEnable()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}