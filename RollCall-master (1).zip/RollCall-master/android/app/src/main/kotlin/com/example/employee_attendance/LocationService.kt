package com.example.employee_attendance

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
import android.location.Location
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat


class LocationService : Service() {
    private val notificationChannelId = "staff_app_notification_location"
    private var mLocationHelper: LocationHelper? = null


    override fun onBind(intent: Intent?): IBinder? {
        return null
    }


    override fun onCreate() {
        super.onCreate()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startNotification()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("GEO_FENCING", "onStartCommand")
        if (mLocationHelper != null) {
            mLocationHelper!!.startListeningUserLocation(object :
                LocationHelper.MyLocationListener {
                override fun onLocationChanged(location: Location?) {
                    location?.let { processLocation(it) }
                }
            })
        } else {
            mLocationHelper = LocationHelper()
            mLocationHelper!!.init(applicationContext)
            mLocationHelper!!.startListeningUserLocation(object :
                LocationHelper.MyLocationListener {
                override fun onLocationChanged(location: Location?) {
                    location?.let { processLocation(it) }
                }
            })
        }
        return START_STICKY
    }

    private fun startNotification() {
        val builder: NotificationCompat.Builder =
            NotificationCompat.Builder(applicationContext, notificationChannelId)
                .setOngoing(true)
                .setWhen(System.currentTimeMillis())
                .setContentTitle("Location Tracking Service is running")
                .setSmallIcon(R.mipmap.ic_launcher)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val notificationChannel = NotificationChannel(
                notificationChannelId,
                notificationChannelId,
                NotificationManager.IMPORTANCE_LOW
            )
            notificationChannel.description = notificationChannelId
            notificationChannel.setSound(null, null)
            notificationManager.createNotificationChannel(notificationChannel)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1, builder.build(),FOREGROUND_SERVICE_TYPE_LOCATION)
        }
        else
        {
            startForeground(1, builder.build())
        }
    }

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    private fun processLocation(location: Location) {
        // Call battery manager service
        val bm = applicationContext.getSystemService(BATTERY_SERVICE) as BatteryManager
        // Get the battery percentage and store it in a INT variable
        val batLevel:Int = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        Log.d("RC", "" + location.latitude + ", " + location.longitude+", battery : "+batLevel)

        if (isInternetAvailable() && MyApplication.userId != null)
        {
            ApiHelper.locationApi(this, MyApplication.userId,location.latitude.toString(),location.longitude.toString())
            ApiHelper.battertApi(this, MyApplication.userId)
        }
    }

    fun Context.isInternetAvailable(): Boolean {
        var result = false

        val connectivityManager =
            applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager?

        connectivityManager?.let {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    it.getNetworkCapabilities(connectivityManager.activeNetwork)?.apply {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            result = when {
                                hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
                                hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
                                else -> false
                            }
                        }
                    }
                } else {
                    TODO("VERSION.SDK_INT < M")
                }
            } else {
                TODO("VERSION.SDK_INT < LOLLIPOP")
            }
        }
        return result
    }

    override fun onDestroy() {
        super.onDestroy()
        stopLocationUpdates()
    }

    private fun stopLocationUpdates() {
        mLocationHelper!!.stopLocationUpdates()
        mLocationHelper = null
    }
}